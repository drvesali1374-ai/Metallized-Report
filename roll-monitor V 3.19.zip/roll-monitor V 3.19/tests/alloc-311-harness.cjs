#!/usr/bin/env node
/* هارنس تست Allocation نسخهٔ ۳٫۱۱ — اجرای «تابع واقعی» allocateByKey استخراج‌شده از calc.js
   سناریوهای ۱۱گانهٔ کاربر + شبیه‌سازی کامل خط لوله: متالایز → ظرفیت مؤثر → خام → برش‌نشده */
'use strict';
const fs = require('fs');
const src = fs.readFileSync('/home/z/my-project/roll-monitor/js/calc.js', 'utf8');

/* --- استخراج متن واقعی تابع از سورس (نه کپی) --- */
const startMarker = 'function allocateByKey(available, candidateSetups, opts) {';
const start = src.indexOf(startMarker);
if (start < 0) throw new Error('allocateByKey پیدا نشد');
let depth = 0, end = -1;
for (let i = src.indexOf('{', start); i < src.length; i++) {
  if (src[i] === '{') depth++;
  else if (src[i] === '}') { depth--; if (depth === 0) { end = i + 1; break; } }
}
const fnCode = src.slice(start, end);
const allocateByKey = new Function('available', 'candidateSetups', 'opts', fnCode + '\n  return allocateByKey(available, candidateSetups, opts);');

/* --- شبیه‌سازی خط لولهٔ کامل ۳٫۱۱: متالایز ← ظرفیت مؤثر ← خام ← برش‌نشده --- */
function pipeline(metCount, rawCount, setups) {
  // گام ۲: Allocation متالایز (ظرفیت = rollCount، آخرین همهٔ باقی‌مانده)
  const met = allocateByKey(metCount, setups, { lastTakesAll: true });
  // گام ۳: ظرفیت مؤثر خام = تعداد − متالایزِ تخصیص‌یافته
  const capacityOf = (s) => s.rollCount - (met.allocation.get(s.id).allocated);
  // گام ۴: Allocation خام (ظرفیت مؤثر + آخرین همهٔ باقی‌مانده)
  const raw = allocateByKey(rawCount, setups, { lastTakesAll: true, capacityOf });
  // گام ۵: برش‌نشدهٔ نهایی = تعداد − (متالایز + خام)
  const rows = setups.map((s) => {
    const m = met.allocation.get(s.id).allocated;
    const r = raw.allocation.get(s.id).allocated;
    const uncut = s.rollCount - (m + r);
    return { id: s.id, met: m, raw: r, uncut, conflict: uncut < 0 ? -uncut : 0 };
  });
  return { rows, rawUnalloc: raw.unallocated, metUnalloc: met.unallocated };
}

let pass = 0, fail = 0;
function check(name, cond, got) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}  ← ${JSON.stringify(got)}`); }
}
const S = (id, rollCount) => ({ id, rollCount });
const fmt = (rows) => rows.map(r => `#${r.id}(m${r.met}/r${r.raw}/u${r.uncut}${r.conflict ? `/⚠${r.conflict}` : ''})`).join(' ');

console.log('— سناریو ۱: یک Setup بدون رقیب —');
{
  // تعداد ۵، متالایز ۲ → ظرفیت خام ۳؛ ۴ خام → ۳ + اضافه ۱ روی خودش (آخرین و تنها)
  const p = pipeline(2, 4, [S(1, 5)]);
  check('ظرفیت مؤثر ۳ و آخرین همهٔ باقی‌مانده (۳+۱ اضافه)', p.rows[0].raw === 4 && p.rows[0].met === 2, p.rows);
  check('برش‌نشده = ۵−(۲+۴) = −۱ → مغایرت ۱', p.rows[0].conflict === 1, p.rows);
  const p2 = pipeline(2, 3, [S(1, 5)]);
  check('دقیقاً ظرفیت: ۳ خام → برش‌نشده ۰ بدون مغایرت', p2.rows[0].raw === 3 && p2.rows[0].uncut === 0 && p2.rows[0].conflict === 0, p2.rows);
}

console.log('— سناریو ۲: دو Setup هم‌کلید (مثال دقیق کاربر) —');
{
  // متالایز ۰ → ظرفیت‌ها ۳ و ۶؛ ۱۰ خام → 3 + 7 (اضافهٔ ۱ روی آخری)
  const p = pipeline(0, 10, [S(1, 3), S(2, 6)]);
  check('A=3، B=7 (نه ۶+۱ تخصیص‌نیافته)', p.rows[0].raw === 3 && p.rows[1].raw === 7 && p.rawUnalloc === 0, p.rows);
  check('مغایرت فقط روی آخری = ۱', p.rows[0].conflict === 0 && p.rows[1].conflict === 1, p.rows);
}

console.log('— سناریو ۳: سه Setup هم‌کلید (مثال‌های دقیق کاربر) —');
{
  let p = pipeline(0, 12, [S(1, 2), S(2, 5), S(3, 9)]);
  check('۱۲ رول → 2/5/5', p.rows.map(r => r.raw).join('/') === '2/5/5', p.rows);
  p = pipeline(0, 7, [S(1, 2), S(2, 5), S(3, 9)]);
  check('۷ رول → 2/5/0', p.rows.map(r => r.raw).join('/') === '2/5/0', p.rows);
  p = pipeline(0, 20, [S(1, 2), S(2, 5), S(3, 9)]);
  check('۲۰ رول → 2/5/13 (C همهٔ باقی‌مانده)', p.rows.map(r => r.raw).join('/') === '2/5/13', p.rows);
  check('اضافه‌تخصیص C = 4 (مغایرت ۴)', p.rows[2].conflict === 4 && p.rows[2].uncut === -4, p.rows);
  check('مجموع تخصیص = تعداد واقعی رول‌ها (بدون شمارش مضاعف)', p.rows.reduce((s, r) => s + r.raw, 0) === 20, p.rows);
}

console.log('— سناریو ۴/۵: کمتر و دقیقاً برابر مجموع ظرفیت —');
{
  let p = pipeline(1, 5, [S(1, 4), S(2, 6)]);
  // متالایز ۱ → ظرفیت‌های مؤثر: #1=3، #2=6 (متالایز به کوچک‌ترین یعنی #1 می‌خورد)
  check('متالایز به رکورد کوچک‌تر (Greedy ASC): #1=1', p.rows[0].met === 1, p.rows);
  check('۵ خام → 3/2 (کمتر از مجموع ۹)', p.rows.map(r => r.raw).join('/') === '3/2', p.rows);
  p = pipeline(1, 9, [S(1, 4), S(2, 6)]);
  check('دقیقاً مجموع ظرفیت مؤثر (۳+۶=۹) → 3/6 بدون مغایرت', p.rows.map(r => r.raw).join('/') === '3/6' && p.rows.every(r => r.conflict === 0), p.rows);
}

console.log('— سناریو ۶: بیشتر از مجموع ظرفیت —');
{
  const p = pipeline(0, 11, [S(1, 3), S(2, 6)]);
  check('۱۱ رول → 3/8 با اضافهٔ ۲ روی آخری', p.rows.map(r => r.raw).join('/') === '3/8', p.rows);
  check('مغایرت آخری = ۲ و برش‌نشدهٔ خام = −۲', p.rows[1].conflict === 2 && p.rows[1].uncut === -2, p.rows);
}

console.log('— سناریو ۷: ظرفیت صفر پس از تخصیص متالایز —');
{
  // #1: تعداد ۳ و متالایز کامل ۳ → ظرفیت مؤثر ۰ → خام نمی‌گیرد (رقیب دارد)
  // #2: تعداد ۵ و متالایز ۰ → ظرفیت ۵؛ ۶ خام → #1=0 و #2=6 (اضافهٔ ۱)
  const p = pipeline(3, 6, [S(1, 3), S(2, 5)]);
  check('متالایز: #1=3 (کوچک‌تر)، #2=0', p.rows[0].met === 3 && p.rows[1].met === 0, p.rows);
  check('ظرفیت صفر → #1 خام نمی‌گیرد (۰)', p.rows[0].raw === 0, p.rows);
  check('آخری همهٔ ۶ را می‌گیرد (اضافهٔ ۱ → مغایرت ۱)', p.rows[1].raw === 6 && p.rows[1].conflict === 1, p.rows);
  // همه ظرفیت صفر: هر دو پُر از متالایز → آخری (id بزرگ‌تر) همهٔ خام را می‌گیرد
  const p2 = pipeline(8, 5, [S(1, 4), S(2, 4)]);
  check('هر دو ظرفیت صفر: آخری (id=2) هر ۵ خام را می‌گیرد', p2.rows[0].raw === 0 && p2.rows[1].raw === 5, p2.rows);
}

console.log('— سناریو ۸/۹: اضافه‌تخصیص + برش‌نشدهٔ منفی (مثال دقیق کاربر) —');
{
  // تعداد ۹، متالایز ۳، خام ۷ → برش‌نشده = ۹−(۳+۷) = −۱
  const p = pipeline(3, 7, [S(1, 9)]);
  check('برش‌نشده = −۱ (مقدار واقعی حفظ)', p.rows[0].uncut === -1, p.rows);
  check('مغایرت ظرفیت = ۱ (قابل مشاهده)', p.rows[0].conflict === 1, p.rows);
  // مثال §5 کاربر: تعداد ۱۰، متالایز ۴ → ظرفیت ۶؛ ۵ خام → برش‌نشده ۱
  const p2 = pipeline(4, 5, [S(1, 10)]);
  check('۱۰/۴/۵ → برش‌نشده ۱', p2.rows[0].uncut === 1 && p2.rows[0].conflict === 0, p2.rows);
  // ۸ خام → برش‌نشده −۲ → مغایرت ۲
  const p3 = pipeline(4, 8, [S(1, 10)]);
  check('۱۰/۴/۸ → برش‌نشده −۲ → مغایرت ۲', p3.rows[0].uncut === -2 && p3.rows[0].conflict === 2, p3.rows);
}

console.log('— سناریو ۱۰: تساوی ظرفیت دو Setup —');
{
  // هر دو ظرفیت مؤثر ۴؛ ۶ خام → اولی (id کوچک‌تر) ۴، آخری ۲
  const p = pipeline(0, 6, [S(1, 4), S(2, 4)]);
  check('تساوی ظرفیت: id کوچک‌تر اول → 4/2', p.rows.map(r => r.raw).join('/') === '4/2', p.rows);
  // با ترتیب ورودی معکوس هم نتیجهٔ یکسان (قطعیت بر اساس id نه ورودی)
  const p2 = pipeline(0, 6, [S(2, 4), S(1, 4)]);
  check('ترتیب ورودی معکوس → همان نتیجه (4 برای id=1)', p2.rows.find(r => r.id === 1).raw === 4 && p2.rows.find(r => r.id === 2).raw === 2, p2.rows);
}

console.log('— سناریو ۱۱: قطعیت در اجرای مجدد (deterministic) —');
{
  const setups = [S(1, 5), S(2, 5), S(3, 8), S(4, 3)];
  const sig = [];
  for (let run = 0; run < 50; run++) {
    // جابه‌جایی تصادفی ترتیب آرایه در هر اجرا
    const shuffled = [...setups].sort(() => Math.random() - 0.5);
    const p = pipeline(6, 14, shuffled);
    sig.push(p.rows.slice().sort((a, b) => a.id - b.id).map(r => `${r.id}:${r.met}/${r.raw}`).join('|'));
  }
  check('۵۰ اجرا با ترتیب ورودی تصادفی → یک نتیجه', new Set(sig).size === 1, [...new Set(sig)].slice(0, 3));
  const p = pipeline(6, 14, setups);
  console.log(`    تخصیص نهایی: ${fmt(p.rows)} — rawUnalloc=${p.rawUnalloc} metUnalloc=${p.metUnalloc}`);
  check('بدون تخصیص‌نیافته در هیچ‌کدام', p.rawUnalloc === 0 && p.metUnalloc === 0, p);
  check('مجموع خام = ۱۴ و متالایز = ۶ (بدون شمارش مضاعف)', p.rows.reduce((s, r) => s + r.raw, 0) === 14 && p.rows.reduce((s, r) => s + r.met, 0) === 6, p.rows);
}

console.log('— رگرسیون متالایز (رفتار ۳٫۷ دست‌نخورده) —');
{
  // ۱۰ متالایز، ظرفیت ۳ و ۶ → 3/7 (رفتار ۳٫۷)
  const met = allocateByKey(10, [S(1, 3), S(2, 6)], { lastTakesAll: true });
  check('متالایز: 3/7 مثل قبل', met.allocation.get(1).allocated === 3 && met.allocation.get(2).allocated === 7, [...met.allocation.entries()]);
  // پیش‌فرض بدون capacityOf → ظرفیت = rollCount
  check('پیش‌فرض capacityOf = rollCount', met.allocation.get(1).capacity === 3, [...met.allocation.entries()]);
}

console.log(`\nنتیجه: ${pass} پاس / ${fail} خطا`);
process.exit(fail ? 1 : 0);
