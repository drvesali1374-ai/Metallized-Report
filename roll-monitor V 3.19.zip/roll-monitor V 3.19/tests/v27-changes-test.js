/* تست منطقی جامع نسخهٔ ۲٫۷:
   ۱) فرمول‌های جدید «مانده زمان ستاپ/موجودی» روی دادهٔ واقعی Backup (۵۹ ستاپ)
   ۲) سه کنترل کیفیت Import (ضخامت ناهمگون · M/R فیلم · بازوی دوبل بعد از M)
      — هم روی دادهٔ واقعی و هم با سناریوهای مصنوعی مو‌به‌مو طبق تعریف کاربر
   ۳) حذف «(§86)» از توضیح مغایرت ظرفیت (بررسی رشتهٔ کد نما) */
'use strict';

import fs from 'node:fs';
import path from 'node:path';

global.window = global;
global.console.warn = () => {};   // خنثی‌کردن هشدارهای بارگذاری
const ROOT = '/home/z/my-project/public/roll-monitor';

function load(file) {
  const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
  eval(code);
}

/* ---- بارگذاری ماژول‌های واقعی ---- */
global.RM = {};
load('js/config.js');
load('js/utils.js');
load('js/normalize.js');
load('js/checks.js');

/* ---- دیتای واقعی Backup کاربر ---- */
const backup = JSON.parse(
  fs.readFileSync('/home/z/my-project/reference/RollMonitor-Backup-1405-06-18.json', 'utf8')

);
const D = backup.data;
const machineTimeRules = (D.appSettings || []).find((s) => s.key === 'machineTimeRules');
const timeRules = machineTimeRules ? machineTimeRules.value : [];

/* ---- استاب دیتابیس برای calc.js و rules.js ---- */
const fakeTables = {
  standardLengthRules: { toArray: async () => D.standardLengthRules },
  setupRolls: { toArray: async () => D.setupRolls },
};
global.RM.db = {
  db: fakeTables,
  loadAllSources: async () => ({
    rolls: D.rolls,
    archivedRolls: D.archivedRolls,
    setupRolls: D.setupRolls,
    rules: D.standardLengthRules,
    importMetadata: D.importMetadata || [],
  }),
  getSetting: async (key, defaultValue) => (key === 'machineTimeRules' ? timeRules : defaultValue),
};

load('js/rules.js');
load('js/setups.js');
load('js/calc.js');

const U = global.RM.utils;
const Checks = global.RM.importChecks;
const Calc = global.RM.calcEngine;
const R = global.RM.rulesEngine;

let pass = 0, fail = 0;
function check(name, actual, expected) {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { pass++; console.log(`  ✓ ${name}`); }
  else {
    fail++;
    console.log(`  ✕ ${name}`);
    console.log(`      actual:   ${JSON.stringify(actual)}`);
    console.log(`      expected: ${JSON.stringify(expected)}`);
  }
}
function checkTrue(name, cond) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✕ ${name}`); }
}

/* ================================================================
   بخش ۱ — فرمول‌های جدید زمان روی دادهٔ واقعی (۵۹ ستاپ)
   ================================================================ */
console.log('\n━━━ ۱) فرمول‌های «مانده زمان ستاپ/موجودی» (نسخهٔ ۲٫۷) ━━━');

const state = await Calc.getState();
const report = state.setupReport;
const summary = state.summary;

check('تعداد رکوردهای گزارش ستاپ', report.length, 59);

/* الف) فرمول مو‌به‌مو برای «همهٔ» رکوردها:
   ستاپ = max(0, تعداد − متالایز) × مدت · موجودی = خام موجود × مدت */
let formulaErrors = 0;
let oldFormulaWouldDiffer = 0;
for (const r of report) {
  if (r.durationMin === null) continue;
  const expSetup = r.durationMin * Math.max(0, r.rollCount - r.metallized);
  const expProduced = r.durationMin * r.rawExisting;
  if (r.remainingSetupTime !== expSetup || r.remainingProducedTime !== expProduced) formulaErrors++;
  // فرمول قدیمی: ستاپ = مدت×تعداد · موجودی = مدت×max(0, تعداد−متالایز)
  if (r.remainingSetupTime !== r.durationMin * r.rollCount) oldFormulaWouldDiffer++;
}
checkTrue(`فرمول جدید روی همهٔ ${report.filter(r=>r.durationMin!==null).length} رکوردِ دارای قانون درست است (${formulaErrors} خطا)`, formulaErrors === 0);
checkTrue(`رفتار از فرمول قدیمی تغییر کرده (${oldFormulaWouldDiffer} رکورد)`, oldFormulaWouldDiffer > 0);

/* ب) مدت زمان از قانون «دستگاه + متراژ استاندارد» استخراج می‌شود */
let durationErrors = 0;
for (const r of report) {
  const rule = R.findTimeRule(timeRules, r.machineNumber, r.standardLength);
  const expected = rule ? rule.durationMin : null;
  if (r.durationMin !== expected) durationErrors++;
}
checkTrue(`مدت هر رکورد از «تعریف قانون زمان متالایز (هر دستگاه)» استخراج می‌شود (${durationErrors} خطا)`, durationErrors === 0);

/* ج) جمع‌ها = Σ فرمول‌های جدید */
let sumSetup = 0, sumProduced = 0;
for (const r of report) {
  sumSetup += r.remainingSetupTime || 0;
  sumProduced += r.remainingProducedTime || 0;
}
check('summary.totalRemainingSetupTime = Σ (تعداد−متالایز)×مدت', summary.totalRemainingSetupTime, sumSetup);
check('summary.totalRemainingProducedTime = Σ خام‌موجود×مدت', summary.totalRemainingProducedTime, sumProduced);

/* د) رکورد نمونهٔ شفاف (اولین رکورد دارای قانون و متالایز>0) */
const sample = report.find((r) => r.durationMin !== null && r.metallized > 0 && r.rawExisting > 0);
if (sample) {
  console.log(`  رکورد نمونه — ستاپ ${sample.setupNumber}/دستگاه ${sample.machineNumber}: تعداد=${sample.rollCount} · متالایز=${sample.metallized} · خام=${sample.rawExisting} · مدت=${sample.durationMin} دقیقه`);
  check('  ستاپ رکورد نمونه', sample.remainingSetupTime, sample.durationMin * Math.max(0, sample.rollCount - sample.metallized));
  check('  موجودی رکورد نمونه', sample.remainingProducedTime, sample.durationMin * sample.rawExisting);
}

/* هـ) رکورد بدون قانون → null (نمایش «بدون قانون») */
const noRule = report.filter((r) => r.durationMin === null);
checkTrue(`${noRule.length} رکورد بدون قانون زمان → هر دو ستون null`, noRule.every((r) => r.remainingSetupTime === null && r.remainingProducedTime === null));

/* و) پایهٔ منفی (متالایز > تعداد → ۰) */
const negBase = report.find((r) => r.rollCount - r.metallized < 0);
checkTrue(
  `پایهٔ منفی به صفر محدود می‌شود${negBase ? ` (ستاپ ${negBase.setupNumber}: ${negBase.rollCount}−${negBase.metallized})` : ' (موردی در دیتا نیست — بررسی مصنوعی)'}`,
  negBase ? negBase.remainingSetupTime === 0 : true
);

/* ================================================================
   بخش ۲ — کنترل ۱: ناهمگونی ضخامت (مصنوعی مو‌به‌مو طبق تعریف کاربر)
   ================================================================ */
console.log('\n━━━ ۲) کنترل ۱ — ناهمگونی ضخامت رول‌های هر ستاپ ━━━');

const mk = (rollNumber, setupNumber, thickness, filmType = 'FMN11') =>
  ({ rollNumber, setupNumber, thickness, filmType, width: 1120, actualLength: 20000 });

/* مثال مو‌به‌مو کاربر: ستاپ ۱۴۰ با ۱۰ رول — ۶ ضخامت ۲۰ + ۴ ضخامت ۳۰ → مبنا ۲۰، ۴ اخطار */
const userExample = Checks.thicknessConflicts([
  mk('A1', 140, 20), mk('A2', 140, 20), mk('A3', 140, 20), mk('A4', 140, 20), mk('A5', 140, 20), mk('A6', 140, 20),
  mk('B1', 140, 30), mk('B2', 140, 30), mk('B3', 140, 30), mk('B4', 140, 30),
]);
check('مثال کاربر: ۱ گروه', userExample.groups.length, 1);
check('مثال کاربر: ضخامت مبنا = ۲۰', userExample.groups[0].majority, 20);
check('مثال کاربر: ۴ رول اخطار (ضخامت ۳۰)', userExample.offenders.length, 4);
check('مثال کاربر: همهٔ اخطارها ضخامت ۳۰', userExample.offenders.every((r) => r.thickness === 30), true);

/* تساوی ۵/۵ → همهٔ ۱۰ رول اخطار */
const tieCase = Checks.thicknessConflicts([
  mk('A1', 140, 20), mk('A2', 140, 20), mk('A3', 140, 20), mk('A4', 140, 20), mk('A5', 140, 20),
  mk('B1', 140, 30), mk('B2', 140, 30), mk('B3', 140, 30), mk('B4', 140, 30), mk('B5', 140, 30),
]);
check('تساوی ۵/۵: همهٔ ۱۰ رول اخطار', tieCase.offenders.length, 10);
check('تساوی ۵/۵: مبنا null', tieCase.groups[0].majority, null);
checkTrue('تساوی ۵/۵: پرچم tie', tieCase.groups[0].tie === true);

/* هم‌ضخامت → بدون اخطار */
check('هم‌ضخامت → بدون گروه', Checks.thicknessConflicts([mk('A1', 1, 20), mk('A2', 1, 20)]).groups.length, 0);

/* ضخامت null مستثنا (در گزارشنمای «بدون ضخامت» جداگانه گزارش می‌شود) */
const nullTh = Checks.thicknessConflicts([mk('A1', 1, 20), mk('A2', 1, 20), mk('A3', 1, null)]);
check('ضخامت null از کنترل مستثنا', nullTh.groups.length, 0);

/* شماره ستاپ null مستثنا */
const nullSetup = Checks.thicknessConflicts([mk('A1', null, 20), mk('A2', null, 30)]);
check('شماره ستاپ null مستثنا', nullSetup.groups.length, 0);

/* سه ضخامت: اکثریت روشن */
const three = Checks.thicknessConflicts([
  mk('A1', 5, 20), mk('A2', 5, 20), mk('A3', 5, 20), mk('B1', 5, 25), mk('C1', 5, 30),
]);
check('سه ضخامت: مبنا = اکثریت (۲۰)', three.groups[0].majority, 20);
check('سه ضخامت: ۲ رول اخطار', three.offenders.length, 2);

/* ================================================================
   بخش ۳ — کنترل ۲: تطابق M/R شماره رول و نوع فیلم
   ================================================================ */
console.log('\n━━━ ۳) کنترل ۲ — تطابق M/R شماره رول و نوع فیلم ━━━');

const film = (rollNumber, filmType) => Checks.filmTypeMismatches([{ rollNumber, filmType }]);

check('M در شماره + M در فیلم → پاس', film('F...R8M2121L1', 'FMN11').items.length, 0);
check('M در شماره + فیلم بدون M → خطا', film('F...R2M31', 'FRN21').items.length, 1);
check('R بدون M + R در فیلم → پاس', film('F2505010071R3', 'FRN21').items.length, 0);
check('R بدون M + M در فیلم → خطا', film('F2505010071R3', 'KMN11').items.length, 1);
check('M+R در شماره + M در فیلم → پاس (اولویت M)', film('F...R3M121R2', 'FMN11').items.length, 0);
check('M+R در شماره + R در فیلم (بدون M) → خطای M', film('F3504510171R2M31', 'FRN21').items.length, 1);
check('M+R در شماره + فیلم بدون M و R → خطای M', film('F...R3M21', 'FXN11').items.length, 1);
check('L بدون M و R + هر فیلم → پاس', film('F2505010121L15', 'FRN21').items.length, 0);
check('شماره رول خالی → مستثنا', film('', 'FMN11').items.length, 0);
check('نوع فیلم خالی → مستثنا', film('F...M21', '').items.length, 0);
check('علت خطای M شامل توضیح', film('F...R2M31', 'FRN21').items[0].reason.includes('M'), true);
check('نوع خطا M', film('F...R2M31', 'FRN21').items[0].kind, 'M');
check('نوع خطا R', film('F...R3', 'KMN11').items[0].kind, 'R');

/* ================================================================
   بخش ۴ — کنترل ۳: بیش از یک بازوی برش (R/L) بعد از M
   ================================================================ */
console.log('\n━━━ ۴) کنترل ۳ — بازوی برش تکراری بعد از M ━━━');

const arm = (num) => Checks.armInfoAfterM(num);

check('M2121L1P0:1 → ۱ بازو', arm('F3504710111R8M2121L1P0:1P1:0').arms, 1);
check('M121R2P0:2D → ۱ بازو', arm('F2301810031R3M121R2P0:2D').arms, 1);
check('M2111R211R2 → ۲ بازو (خطا)', arm('K2502610071R2M2111R211R2').arms, 2);
check('M3111R231R2P2:0 → ۲ بازو (خطا)', arm('F3503710032R6M3111R231R2P2:0').arms, 2);
check('M31 → ۰ بازو', arm('F3504510171R2M31').arms, 0);
check('M21 → ۰ بازو', arm('F3504710071R8M21').arms, 0);
check('بدون M → hasM=false', arm('K2503330611R2').hasM, false);
check('ناحیه M2121L1', arm('F...M2121L1P0:1').zone, '2121L1');
check('ناحیه 2111R211R2', arm('F...M2111R211R2').zone, '2111R211R2');
check('حروف بازو L', arm('F...M2121L1P0:1').letters.join(''), 'L');
check('حروف بازو RR', arm('F...M2111R211R2').letters.join(''), 'RR');
check('L13 قبل از M شمرده نمی‌شود', arm('F2309310502L13M221L1D').arms, 1);
check('M211L3D → ۱ بازو', arm('F2309310471R3M211L3D').arms, 1);
check('M31C1 (پایان ناحیه با C) → ۰ بازو', arm('F...M31C1').arms, 0);

const dbl = Checks.doubleArmAfterM([
  { rollNumber: 'F...M2121L1P0:1' }, { rollNumber: 'F...M2111R211R2' }, { rollNumber: 'F...R3' },
]);
check('doubleArmAfterM: فقط رول دوبل‌بازو', dbl.items.length, 1);
check('شماره رول خالی → مستثنا', Checks.doubleArmAfterM([{ rollNumber: '' }]).items.length, 0);

/* ================================================================
   بخش ۵ — کنترل‌ها روی دادهٔ واقعی Backup
   ================================================================ */
console.log('\n━━━ ۵) کنترل‌ها روی دادهٔ واقعی (رول‌های موجود + آرشیو) ━━━');

const resRolls = Checks.validateAll(D.rolls);
const resArch = Checks.validateAll(D.archivedRolls);

/* رول‌های موجود: ۷ ستاپ ناهمگون / ۲۰ رول اخطار (شامل tie ستاپ ۱۵۱) */
check('رول‌های موجود: ۷ ستاپ ناهمگون', resRolls.counts.thicknessSetups, 7);
check('رول‌های موجود: ۲۰ رول ضخامت اخطار', resRolls.counts.thickness, 20);
checkTrue('رول‌های موجود: ستاپ ۱۵۱ تساوی ۲/۲ (همهٔ ۴ رول)', resRolls.thickness.groups.some((g) => g.setupNumber === 151 && g.tie && g.offenders.length === 4));
checkTrue('رول‌های موجود: ستاپ ۷۹ مبنا ۲۰ (۷۳ رول) · ۶ اخطار', resRolls.thickness.groups.some((g) => g.setupNumber === 79 && g.majority === 20 && g.offenders.length === 6));

/* خطاهای M/R فیلم — همان ۳ رول واقعی */
const filmRolls = [...resRolls.film.items, ...resArch.film.items].map((it) => it.record.rollNumber).sort();
check('کل خطاهای M/R (هر دو فایل) = ۳ رول واقعی', filmRolls, [
  'F2503640621R3M2111R211R2'.slice(0, 0) + 'F3502630261R4M21',
  'F3504510171R2M31',
  'F3504510242L5M31',
]);

/* بازوی دوبل — همان ۳ رول واقعی */
const armRolls = [...resRolls.arm.items, ...resArch.arm.items].map((it) => it.record.rollNumber).sort();
check('کل بازوهای دوبل (هر دو فایل) = ۳ رول واقعی', armRolls, [
  'F2503640621R3M2111R211R2',
  'F3503710032R6M3111R231R2P2:0',
  'K2502610071R2M2111R211R2',
]);

/* آرشیو: ۱۳ ستاپ ناهمگون / ۳۱۱ اخطار */
check('آرشیو: ۱۳ ستاپ ناهمگون', resArch.counts.thicknessSetups, 13);
check('آرشیو: ۳۱۱ رول ضخامت اخطار', resArch.counts.thickness, 311);

/* توزیع خطاها بین دو فایل */
console.log(`  توزیع: rolls → ضخامت ${resRolls.counts.thickness} · فیلم ${resRolls.counts.film} · بازو ${resRolls.counts.arm}`);
console.log(`  توزیع: archived → ضخامت ${resArch.counts.thickness} · فیلم ${resArch.counts.film} · بازو ${resArch.counts.arm}`);

/* ۳۲۷۵ رول M با فیلم M → صفر خطای M در مجموع */
checkTrue('همهٔ ۳۲۷۵ رول M شماره، فیلم M دارند (صفر خطای اضافی)', resRolls.counts.film + resArch.counts.film === 3);

/* validateAll: شمارش‌ها و پرچم clean */
const clean = Checks.validateAll([mk('A1', 1, 20, 'FMN11'), mk('F...M2121L1', 20, 'FMN11'), { rollNumber: 'F...R3', filmType: 'FRN21', thickness: 20, setupNumber: 1 }]);
check('دیتای سالم → clean=true', clean.clean, true);
check('clean=false با یک خطا', Checks.validateAll([mk('F...R3M21', 1, 20, 'FRN21')]).clean, false);
/* counts.total = ۲ خطای ضخامت (تساوی ۱/۱ → هر دو رول) + ۱ خطای فیلم = ۳ */
check('counts.total صحیح', Checks.validateAll([mk('F...R3M21', 1, 20, 'FRN21'), mk('B1', 1, 30)]).counts.total, 3);

/* ================================================================
   بخش ۶ — حذف «(§86)» از رشته‌های قابل‌مشاهده
   ================================================================ */
console.log('\n━━━ ۶) حذف «(§86)» از توضیح مغایرت ظرفیت ━━━');

const setupViewCode = fs.readFileSync(path.join(ROOT, 'js/views/setup.js'), 'utf8');
const renderedTitles = setupViewCode.match(/title="[^"]*مغایرت ظرفیت[^"]*"/g) || [];
checkTrue(`همهٔ titleهای «مغایرت ظرفیت» بدون (§86) (${renderedTitles.length} مورد)`, renderedTitles.length > 0 && renderedTitles.every((t) => !t.includes('§86')));
checkTrue('توضیح جدید مغایرت ظرفیت شامل علت است', renderedTitles.some((t) => t.includes('خام موجود + متالایز')));

/* ================================================================
   نتیجهٔ نهایی
   ================================================================ */
console.log('\n════════════════════════════════════');
console.log(`نتیجه: ${pass} پاس · ${fail} خطا`);
if (fail > 0) process.exit(1);
