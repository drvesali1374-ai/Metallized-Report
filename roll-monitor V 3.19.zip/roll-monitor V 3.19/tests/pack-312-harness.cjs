#!/usr/bin/env node
/* هارنس تست موتور بسته‌بندی (نسخهٔ ۳٫۱۳ — به‌روز برای دامنهٔ فروش/پای‌کار) — اجرای «فایل واقعی» js/packaging.js در Node
   با RM ساختگی (config + utils) — سناریوهای سند بسته‌بندی (§۱۹، §۱۷، §۱۴، §۱۳، §۲۲)
   + موارد مرزی (اضافه‌ظرفیت، تنزل هدف، اهداکنندهٔ جزئی، رزرو، دامنه، تعیین‌ناپذیری). */
'use strict';

const fs = require('fs');

/* ---------- ساخت RM ساختگی ---------- */
const toLatin = (s) => String(s ?? '').replaceAll('۰', '0').replaceAll('۱', '1').replaceAll('۲', '2')
  .replaceAll('۳', '3').replaceAll('۴', '4').replaceAll('۵', '5').replaceAll('۶', '6')
  .replaceAll('۷', '7').replaceAll('۸', '8').replaceAll('۹', '9').replaceAll('٠', '0');
global.window = global;
global.RM = {
  config: {
    PALLET_RULES: {
      FILM_METAL_LETTER: 'M',
      LINE_BY_FIRST_CHAR: { F: 'BOPP', K: 'CPP' },
      VALID_DIAMETERS: [3, 6],
      WAREHOUSE_PREFIX: 'انبار',
      D3_WIDTH_LAYERS: 800,
      BOPP_D6_WIDTH: 850,
      CPP_D6_WIDTH: 600,
      TARGETS_D3_STD8: [8, 7, 4, 3],
      TARGETS_D3_STD4: [4, 3],
    },
  },
  utils: {
    toLatinDigits: toLatin,
    parseNumber: (v) => (v === null || v === undefined || v === '' ? null : Number(v)),
    parseInt: (v) => (v === null || v === undefined || v === '' ? null : Math.trunc(Number(v))),
  },
};

eval(fs.readFileSync('/home/z/my-project/roll-monitor/js/packaging.js', 'utf8'));
const P = RM.packaging;

/* ---------- سازندهٔ رکورد پالت ---------- */
let rollSeq = 0;
function pallet(o) {
  const rolls = typeof o.rolls === 'number'
    ? Array.from({ length: o.rolls }, () => `T${String(++rollSeq).padStart(4, '0')}`)
    : (o.rolls || []);
  return {
    palletId: o.id || o.no,
    palletNo: o.no,
    filmType: o.film || 'FMN11',
    thickness: o.thick ?? 20,
    width: o.width,
    grade: o.grade || 'X',
    packType: o.pk ?? 'H6',
    rolls,
    rollListRaw: rolls.join(','),
    warehouse: o.wh || 'انبار تست',
    productionDate: null, netWeight: null, grossWeight: null,
    setupNumber: null, customerCode: '', techSpec: '',
    source: 'pallets', raw: {},
  };
}

/* ---------- چک‌کننده ---------- */
let pass = 0, fail = 0;
function check(name, cond, got) {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}  ← ${JSON.stringify(got)}`); }
}

/* عرض‌های استاندارد: V3 w<800 → 8 · V3 w>=800 → 4 · H6 BOPP w>=850 → 2 ·
   V6 BOPP w<850 → 2 · H6 CPP w>=600 → 2 · H6 CPP w<600 → 4 */
const V3W = { std8: 700, std4: 900 };      // بوبین ۳
const D6W = { boppH: 1000, boppV: 800, cpp2: 700, cpp4: 425 }; // بوبین ۶

/* ================================================================ */
console.log('— سناریو ۱ (سند §۱۹): A=5, B=3, C=2 با هدف ۸ → بستهٔ A+3 از B —');
{
  const recs = [
    pallet({ no: 'A', width: V3W.std8, pk: 'V3', rolls: 5 }),
    pallet({ no: 'B', width: V3W.std8, pk: 'V3', rolls: 3 }),
    pallet({ no: 'C', width: V3W.std8, pk: 'V3', rolls: 2 }),
  ];
  const plan = P.buildPlan(recs);
  const pkg = plan.packages[0];
  check('دقیقاً یک بسته', plan.packages.length === 1, plan.packages.length);
  check('پالت اصلی A با ظرفیت ۸', pkg.mainPalletNo === 'A' && pkg.target === 8,
    { main: pkg.mainPalletNo, target: pkg.target });
  check('۳ رول مکمل فقط از B (۲ پالت مشارکت‌کننده)', pkg.complementRolls.length === 3 &&
    pkg.complementRolls.every((r) => r.pallet.palletNo === 'B'), pkg.complementRolls.map((r) => r.pallet.palletNo));
  check('C غیرقابل بسته‌بندی (باقی‌مانده)', plan.pallets.find((p) => p.palletNo === 'C').planState === 'unpacked');
  check('B تخلیه‌شده', plan.pallets.find((p) => p.palletNo === 'B').planState === 'donor-empty');
  check('پالت مرجوعی = B', pkg.recallPallets.length === 1 && pkg.recallPallets[0].palletNo === 'B', pkg.recallPallets);
  check('۳ جابه‌جایی', plan.stats.movesTotal === 3, plan.stats.movesTotal);
}

console.log('— سناریو ۲ (سند §۱۸): گروه [2,2,1,1,2] استاندارد ۴ → بستهٔ ۴ + بستهٔ ۳ بدون باقی‌مانده —');
{
  const recs = [
    pallet({ no: 'P1', width: V3W.std4, pk: 'V3', rolls: 2 }),
    pallet({ no: 'P2', width: V3W.std4, pk: 'V3', rolls: 2 }),
    pallet({ no: 'P3', width: V3W.std4, pk: 'V3', rolls: 1 }),
    pallet({ no: 'P4', width: V3W.std4, pk: 'V3', rolls: 1 }),
    pallet({ no: 'P5', width: V3W.std4, pk: 'V3', rolls: 1 }),
  ];
  const plan = P.buildPlan(recs);
  const targets = plan.packages.map((x) => x.target).sort((a, b) => b - a);
  check('دو بسته با اهداف ۴ و ۳', plan.packages.length === 2 && targets[0] === 4 && targets[1] === 3, targets);
  check('همهٔ ۷ رول بسته شد (صفر باقی‌مانده)', plan.stats.rollsPacked === 7 &&
    plan.stats.rollsLeftover === 0, { packed: plan.stats.rollsPacked, left: plan.stats.rollsLeftover });
  const pkg4 = plan.packages.find((x) => x.target === 4);
  check('بستهٔ ۴: پالت اصلی + فقط ۱ اهداکنندهٔ کامل', pkg4.complementRolls.length === 2 &&
    new Set(pkg4.complementRolls.map((r) => r.pallet.palletNo)).size === 1, pkg4.complementRolls.map((r) => r.pallet.palletNo));
}

console.log('— سناریو ۳ (سند §۱۴): [2,1,1] استاندارد ۸ → تلاش ۸، ۷ و سپس بستهٔ ۴ —');
{
  const recs = [
    pallet({ no: 'M1', width: V3W.std8, pk: 'V3', rolls: 2 }),
    pallet({ no: 'M2', width: V3W.std8, pk: 'V3', rolls: 1 }),
    pallet({ no: 'M3', width: V3W.std8, pk: 'V3', rolls: 1 }),
  ];
  const plan = P.buildPlan(recs);
  check('یک بسته با هدف ۴ (اولویت ۸→۷→۴)', plan.packages.length === 1 && plan.packages[0].target === 4,
    plan.packages.map((x) => x.target));
  check('هر دو پالت ۱روله تخلیه شدند', plan.stats.donorEmptyPallets === 2, plan.stats.donorEmptyPallets);
}

console.log('— سناریو ۴ (سند §۱۴+§۲۲): [2,4] استاندارد ۸ → ۴ در ظرفیت هدف (۳٫۱۴ بند ۱: بدون شمارهٔ بسته) —');
{
  const recs = [
    pallet({ no: 'K1', width: V3W.std8, pk: 'V3', rolls: 2 }),
    pallet({ no: 'K2', width: V3W.std8, pk: 'V3', rolls: 4 }),
  ];
  const plan = P.buildPlan(recs);
  check('۳٫۱۴ بند ۱: بستهٔ as-is شماره نمی‌گیرد و در برنامه نیست — در asIsPackages است',
    plan.packages.length === 0 && plan.asIsPackages.length === 1 &&
    plan.asIsPackages[0].type === 'as-is' && plan.asIsPackages[0].mainPalletNo === 'K2' &&
    plan.asIsPackages[0].no === undefined,
    { pkgs: plan.packages.length, asIs: plan.asIsPackages.length });
  check('رول‌های پالت as-is «بسته‌بندی‌شده» بدون شمارهٔ بسته',
    plan.stats.rollsPacked === 4 &&
    plan.rollStates.filter((r) => r.status === 'packed' && !r.packageNo).length === 4,
    { packed: plan.stats.rollsPacked });
  check('رول‌های K1 باقی‌مانده‌اند (رزرو فقط برای بسته‌های قابل اقدام)',
    plan.stats.rollsLeftover === 2 && plan.stats.rollsReserve === 0,
    { left: plan.stats.rollsLeftover, res: plan.stats.rollsReserve });
  check('۳٫۱۳: بستهٔ as-is «قابل اقدام» نیست (از جدول برنامه حذف می‌شود)',
    plan.stats.packagesActionable === 0 && plan.stats.packagesAsIs === 1,
    { act: plan.stats.packagesActionable, asIs: plan.stats.packagesAsIs });
}

console.log('— سناریو ۵ (سند §۱۳): CPP عرض ۴۲۵ [1,2] → هدف فقط ۴ → هیچ بستهٔ قابل قبول —');
{
  const recs = [
    pallet({ no: 'C1', film: 'KMN11', width: D6W.cpp4, pk: 'H6', rolls: 1 }),
    pallet({ no: 'C2', film: 'KMN11', width: D6W.cpp4, pk: 'H6', rolls: 2 }),
  ];
  const plan = P.buildPlan(recs);
  check('ظرفیت استاندارد ۴ و هدف فقط [4]', plan.pallets[0].stdCapacity === 4 &&
    JSON.stringify(plan.pallets[0].targets) === '[4]', plan.pallets[0].targets);
  check('هیچ بسته ساخته نشد (۳ رول ≠ ۴ قابل قبول نیست)', plan.packages.length === 0, plan.packages.length);
  check('هر دو پالت باقی‌مانده', plan.stats.unpackedPallets === 2, plan.stats.unpackedPallets);
}

console.log('— سناریو ۶: [1,3] استاندارد ۴ (اهدای بخشی سند §۱۷) → بستهٔ ۴ با ۱ رول از پالت ۳تایی؟ خیر — ۳تایی اصلی —');
{
  const recs = [
    pallet({ no: 'D1', width: V3W.std4, pk: 'V3', rolls: 1 }),
    pallet({ no: 'D2', width: V3W.std4, pk: 'V3', rolls: 3 }),
  ];
  const plan = P.buildPlan(recs);
  const pkg = plan.packages[0];
  check('پالت ۳تایی اصلی + ۱ مکمل از پالت ۱روله = بستهٔ ۴',
    pkg.mainPalletNo === 'D2' && pkg.target === 4 && pkg.complementRolls.length === 1 &&
    pkg.complementRolls[0].pallet.palletNo === 'D1',
    { main: pkg.mainPalletNo, comp: pkg.complementRolls.map((r) => r.pallet.palletNo) });
}

console.log('— سناریو ۷: [1,1,1] استاندارد ۲ → یک بستهٔ ۲ + یک باقی‌مانده —');
{
  const recs = ['E1', 'E2', 'E3'].map((no) => pallet({ no, width: D6W.boppH, pk: 'H6', rolls: 1 }));
  const plan = P.buildPlan(recs);
  check('یک بستهٔ ۲ با یک اهداکنندهٔ کامل', plan.packages.length === 1 &&
    plan.packages[0].target === 2 && plan.packages[0].moves === 1, plan.packages.length);
  check('یک پالت باقی‌ماندهٔ ۱روله (رزرو)', plan.stats.unpackedPallets === 1 && plan.stats.rollsReserve === 1,
    { unp: plan.stats.unpackedPallets, res: plan.stats.rollsReserve });
}

console.log('— سناریو ۸: [1,1,1,1] استاندارد ۲ → دو بستهٔ ۲ —');
{
  const recs = ['F1', 'F2', 'F3', 'F4'].map((no) => pallet({ no, width: D6W.boppH, pk: 'H6', rolls: 1 }));
  const plan = P.buildPlan(recs);
  check('دو بستهٔ ۲ (چهار رول بسته، صفر باقی‌مانده)', plan.packages.length === 2 &&
    plan.stats.rollsPacked === 4 && plan.stats.rollsLeftover === 0,
    { pkgs: plan.packages.length, packed: plan.stats.rollsPacked });
}

console.log('— سناریو ۹ (سند §۸): بیش از ظرفیت [3,1] استاندارد ۲ → تخلیهٔ مازاد + جذب در بستهٔ بعدی —');
{
  const recs = [
    pallet({ no: 'G1', width: D6W.boppH, pk: 'H6', rolls: 3 }),
    pallet({ no: 'G2', width: D6W.boppH, pk: 'H6', rolls: 1 }),
  ];
  const plan = P.buildPlan(recs);
  const g1 = plan.pallets.find((p) => p.palletNo === 'G1');
  const pkg = plan.packages.find((x) => x.mainPalletNo === 'G2');
  check('G1 مازاد ۱ رول جدا شد و کامل ماند', g1.planState === 'complete' && g1.shedCount === 1,
    { st: g1.planState, shed: g1.shedCount });
  check('رول مازاد در بستهٔ G2 جذب شد (۱ جابه‌جایی)', pkg && pkg.target === 2 &&
    pkg.complementRolls.length === 1 && pkg.complementRolls[0].pallet.palletNo === 'G1',
    pkg && pkg.complementRolls.map((r) => r.pallet.palletNo));
}

console.log('— سناریو ۱۰ (سند §۱۴): پالت ۵رولهٔ تنها در استاندارد ۸ → تنزل به هدف ۴ —');
{
  const recs = [pallet({ no: 'H1', width: V3W.std8, pk: 'V3', rolls: 5 })];
  const plan = P.buildPlan(recs);
  const pkg = plan.packages[0];
  check('بستهٔ تنزل‌یافته با هدف ۴ و ۱ رول مازاد', pkg && pkg.type === 'downgraded' && pkg.target === 4,
    pkg && { type: pkg.type, target: pkg.target });
  check('رول مازاد = رزرو همان بسته (هم‌گروه)', plan.stats.rollsReserve === 1 && pkg.reserveRolls.length === 1,
    { res: plan.stats.rollsReserve, pkgRes: pkg.reserveRolls.length });
}

console.log('— سناریو ۱۱ (سند §۱۷): اهدای «بخشی» — [3,2] استاندارد ۸ → بستهٔ ۴ + اهداکنندهٔ جزئی ۱روله —');
{
  const recs = [
    pallet({ no: 'I1', width: V3W.std8, pk: 'V3', rolls: 3 }),
    pallet({ no: 'I2', width: V3W.std8, pk: 'V3', rolls: 2 }),
  ];
  const plan = P.buildPlan(recs);
  const i2 = plan.pallets.find((p) => p.palletNo === 'I2');
  const pkg = plan.packages[0];
  check('بستهٔ ۴ = ۳ اصل + ۱ مکمل جزئی از I2', pkg.target === 4 && pkg.complementRolls.length === 1 &&
    pkg.complementRolls[0].pallet.palletNo === 'I2', pkg.target);
  check('I2 اهداکنندهٔ جزئی (۱ رول مانده = رزرو)', i2.planState === 'donor-partial' &&
    plan.stats.rollsReserve === 1, { st: i2.planState, res: plan.stats.rollsReserve });
}

console.log('— سناریو ۱۲ (سند §۶): مغایرت نوع بسته‌بندی اکسل H6 ↔ محاسبه‌شده V6 —');
{
  const recs = [pallet({ no: 'J1', width: D6W.boppV, pk: 'H6', rolls: 2 })]; // BOPP عرض ۸۰۰ < ۸۵۰ → V6
  const plan = P.buildPlan(recs);
  const warn = plan.warnings.find((w) => w.key === 'mismatch');
  check('نوع محاسبه‌شده V6 و هشدار مغایرت', plan.pallets[0].computedType === 'V6' &&
    warn && warn.pallets.length === 1, { t: plan.pallets[0].computedType, w: !!warn });
  check('پالتِ مغایرت همچنان در برنامه (کامل V6)', plan.pallets[0].planState === 'complete');
}

console.log('— سناریو ۱۳ (سند §۷): نوع بسته‌بندی نامعتبر/خالی → مستثنا + هشدار —');
{
  const recs = [
    pallet({ no: 'L1', width: 1000, pk: '', rolls: 2 }),
    pallet({ no: 'L2', width: 1000, pk: 'X', rolls: 1 }),
    pallet({ no: 'L3', width: 1000, pk: 'H6', rolls: 2 }),
  ];
  const plan = P.buildPlan(recs);
  const warn = plan.warnings.find((w) => w.key === 'invalidPack');
  check('دو پالت نامعتبر مستثنا شدند + هشدار', plan.stats.excluded === 2 && warn && warn.pallets.length === 2,
    { ex: plan.stats.excluded, w: warn && warn.pallets.length });
  check('پالت سالم در برنامه ماند', plan.pallets.find((p) => p.palletNo === 'L3').planState === 'complete');
  check('رول‌های پالت مستثنا وضعیت «مستثنا» دارند', plan.stats.rollsExcluded === 3, plan.stats.rollsExcluded);
}

console.log('— سناریو ۱۴ (۳٫۱۳ — بند ۵): پالت «فروش» همیشه کنار — انبار + پای کار در برنامه —');
{
  const recs = [
    pallet({ no: 'N1', width: D6W.boppH, pk: 'H6', rolls: 1, wh: 'انبار راما' }),
    pallet({ no: 'N2', width: D6W.boppH, pk: 'H6', rolls: 1, wh: 'پای کار خط ۲' }),
    pallet({ no: 'N3', width: D6W.boppH, pk: 'H6', rolls: 1, wh: 'خروج از انبار - فروش' }),
  ];
  const plan = P.buildPlan(recs);
  check('فروش‌شده کنار؛ انبار + پای کار در برنامه',
    plan.stats.soldPallets === 1 && plan.stats.inScope === 2,
    { in: plan.stats.inScope, sold: plan.stats.soldPallets });
  check('بستهٔ ۲تایی از پالت انبار + پالت پای کار',
    plan.packages.length === 1 && plan.packages[0].target === 2, plan.packages.length);
  const n2 = plan.pallets.find((x) => x.palletNo === 'N2');
  check('پرچم پای کار (atBase) روی N2', n2.atBase === true && n2.sold === false,
    { atBase: n2.atBase, sold: n2.sold });
  const pkg = plan.packages[0];
  check('palletParts: هر دو پالت بسته با پرچم پای کار (اصلی + مکمل)',
    pkg.palletParts.length === 2 &&
    pkg.palletParts.filter((x) => x.atBase).length === 1 &&
    pkg.palletParts.some((x) => x.isMain) &&
    pkg.palletParts.every((x) => Array.isArray(x.rolls) && x.rolls.length === 1),
    pkg.palletParts.map((x) => [x.palletNo, x.atBase]));
  check('رول‌های palletParts با نقش بسته هم‌خوان‌اند',
    pkg.palletParts.reduce((s, x) => s + x.rolls.length, 0) === pkg.finalCount,
    { sum: pkg.palletParts.reduce((s, x) => s + x.rolls.length, 0), final: pkg.finalCount });
  check('آمار «نیازمند آوردن از انبار» پالت پای کار را نمی‌شمارد',
    plan.stats.recallPalletCount === 1, plan.stats.recallPalletCount);
}

console.log('— سناریو ۱۷ (۳٫۱۴ — بند ۱): شماره‌گذاری پیوسته — بستهٔ as-is شماره نمی‌گیرد و خلأ نمی‌گذارد —');
{
  /* گروه اول (فیلم FMN11): پالت ۴رولهٔ تنها در استاندارد ۸ → در ظرفیت هدف ۴ → as-is
     گروه دوم (فیلم FMN21): [2,1,1] استاندارد ۴ → یک بستهٔ ۴ (قابل اقدام) */
  const recs = [
    pallet({ no: 'Q1', film: 'FMN11', width: V3W.std8, pk: 'V3', rolls: 4 }),
    pallet({ no: 'Q2', film: 'FMN21', width: V3W.std4, pk: 'V3', rolls: 2 }),
    pallet({ no: 'Q3', film: 'FMN21', width: V3W.std4, pk: 'V3', rolls: 1 }),
    pallet({ no: 'Q4', film: 'FMN21', width: V3W.std4, pk: 'V3', rolls: 1 }),
  ];
  const plan = P.buildPlan(recs);
  const nos = plan.packages.map((x) => x.no);
  check('شمارهٔ بستهٔ قابل اقدام از ۱ شروع و پیوسته است (بدون خلأِ as-is)',
    plan.packages.length === 1 && nos[0] === 1, nos);
  check('بستهٔ as-is گروه اول شماره نگرفته و در برنامه نیست',
    plan.asIsPackages.length === 1 && plan.asIsPackages[0].mainPalletNo === 'Q1' &&
    plan.asIsPackages[0].no === undefined && plan.stats.packagesAsIs === 1,
    plan.asIsPackages.map((x) => [x.mainPalletNo, x.no]));
  check('رول‌های بستهٔ as-is بسته‌بندی‌شده بدون شمارهٔ بسته‌اند',
    plan.rollStates.filter((r) => r.status === 'packed' && !r.packageNo).length === 4,
    plan.rollStates.filter((r) => r.status === 'packed' && !r.packageNo).length);
}

console.log('— سناریو ۱۸ (۳٫۱۴ — بند ۵): تفکیک پالت‌های صادراتی (پایان شماره با E) —');
{
  const mk = (no) => pallet({ no, width: D6W.boppH, pk: 'H6', rolls: 1 });
  const recs = [mk('FFG07013059E'), mk('FFG06140815')];   // یکی صادراتی + یکی معمولی (هم‌ویژگی)
  const mixed = P.buildPlan(recs);
  check('پیش‌فرض (بدون تفکیک): رول صادراتی با معمولی بسته می‌شود',
    mixed.packages.length === 1 && mixed.packages[0].target === 2 &&
    mixed.stats.separateExport === false,
    { pkgs: mixed.packages.length, sep: mixed.stats.separateExport });

  const sep = P.buildPlan(recs, { separateExport: true });
  check('با تفکیک: صادراتی گروه جدا می‌گیرد → هیچ بستهٔ ۲تایی شکل نمی‌گیرد',
    sep.packages.length === 0 && sep.stats.unpackedPallets === 2 &&
    sep.stats.groups === 2 && sep.stats.exportGroups === 1 &&
    sep.stats.separateExport === true,
    { pkgs: sep.packages.length, groups: sep.stats.groups, exGroups: sep.stats.exportGroups });
  check('پرچم صادراتی فقط روی پالت پایان‌E',
    sep.pallets.filter((p) => p.isExport).length === 1 &&
    sep.pallets.find((p) => p.palletNo === 'FFG07013059E').isExport === true &&
    sep.pallets.find((p) => p.palletNo === 'FFG06140815').isExport === false,
    sep.pallets.map((p) => [p.palletNo, p.isExport]));

  const bothE = P.buildPlan([mk('FFG07013059E'), mk('FFF21010930E')], { separateExport: true });
  check('دو پالت صادراتی با تفکیب: با هم بسته می‌شوند (گروه صادراتی)',
    bothE.packages.length === 1 && bothE.packages[0].target === 2,
    bothE.packages.length);
}

console.log('— سناریو ۱۵: تعیین‌ناپذیری — دو اجرا امضای یکسان —');
{
  const recs = [
    pallet({ no: 'Z2', width: V3W.std8, pk: 'V3', rolls: 2 }),
    pallet({ no: 'Z1', width: V3W.std8, pk: 'V3', rolls: 2 }),
    pallet({ no: 'Z3', width: V3W.std4, pk: 'V3', rolls: 1 }),
    pallet({ no: 'Z4', width: D6W.boppH, pk: 'H6', rolls: 1 }),
    pallet({ no: 'Z5', width: D6W.boppH, pk: 'H6', rolls: 1 }),
  ];
  const sig = (plan) => JSON.stringify({
    p: plan.packages.map((x) => [x.no, x.mainPalletNo, x.target, x.type,
      x.complementRolls.map((r) => [r.pallet.palletNo, r.roll])]),
    r: plan.rollStates.map((r) => [r.roll, r.status, r.packageNo, r.role, r.movedToPalletNo]),
  });
  check('امضای دو اجرا یکسان است', sig(P.buildPlan(recs)) === sig(P.buildPlan(recs)));
}

console.log('— سناریو ۱۶: خط تولید CPP و BOPP (سند §۵) + جهت‌ها (§۹-§۱۱) —');
{
  const cases = [
    { film: 'FMN11', width: 900, pk: 'V3', expect: { line: 'BOPP', type: 'V3', std: 4, dir: 'V', layers: 1 } },
    { film: 'FMN11', width: 700, pk: 'V3', expect: { line: 'BOPP', type: 'V3', std: 8, dir: 'V', layers: 2 } },
    { film: 'FMN11', width: 1000, pk: 'H6', expect: { line: 'BOPP', type: 'H6', std: 2, dir: 'H', layers: 2 } },
    { film: 'FMN11', width: 800, pk: 'V6', expect: { line: 'BOPP', type: 'V6', std: 2, dir: 'V', layers: 2 } },
    { film: 'KMN11', width: 700, pk: 'H6', expect: { line: 'CPP', type: 'H6', std: 2, dir: 'H', layers: 2 } },
    { film: 'KMN11', width: 425, pk: 'H6', expect: { line: 'CPP', type: 'H6', std: 4, dir: 'H', layers: 2 } },
  ];
  let allOk = true;
  const got = [];
  for (const c of cases) {
    const d = P.derivePallet(pallet({ no: 'X', film: c.film, width: c.width, pk: c.pk, rolls: 1 }));
    const ok = d.line === c.expect.line && d.computedType === c.expect.type &&
      d.stdCapacity === c.expect.std && d.direction === c.expect.dir && d.layers === c.expect.layers;
    if (!ok) allOk = false;
    got.push({ w: c.width, line: d.line, type: d.computedType, std: d.stdCapacity, dir: d.direction, l: d.layers });
  }
  check('هر ۶ قانون ظرفیت/جهت درست است', allOk, got);
}

console.log('');
console.log(`نتیجه: ${pass} پاس / ${fail} خطا`);
process.exit(fail ? 1 : 0);
