/* =========================================================================
   views/dashboard.js — نما داشبورد (§57-§59، §52)
   -------------------------------------------------------------------------
   این نما هیچ محاسبه‌ای انجام نمی‌دهد؛ فقط از موتور محاسبهٔ مرکزی
   (RM.calcEngine) تغذیه می‌کند (Single Source of Truth — §105).
   ========================================================================= */

'use strict';

(function () {
  const U = RM.utils;
  const UI = RM.ui;
  const db = RM.db.db;

  const Dashboard = { _state: null };   // آخرین وضعیت محاسبه (برای Drill-down هشدارها)

  Dashboard._avgMachines = null;       // دستگاه‌های روشنِ میانگین ماتریس (نسخهٔ ۳٫۵ — تغییر ۴): null = هنوز بارگذاری نشده

  /* ================================================================
     موتور نمودارهای ECharts (نسخهٔ ۲٫۳ — کاملاً لوکال)
     ----------------------------------------------------------------
     - کتابخانه از lib/echarts.min.js لوکال بارگذاری می‌شود (بدون CDN)
     - رنگ‌ها از همان پالت CSS (زمردی/فیروزه‌ای/کهربایی/رز) — بدون آبی
     - تم روشن/تاریک پشتیبانی می‌شود (با تغییر تم، نمودارها تازه می‌شوند)
     - در نبود کتابخانه → Fallback به نمودار CSS قبلی (آفلاین مقاوم)
     ================================================================ */

  Dashboard._charts = {};          // id → نمونهٔ echarts
  Dashboard._pendingCharts = false; // دادهٔ تازه در تب مخفی — هنگام نمایش رندر شود

  /** آیا ECharts لوکال در دسترس است؟ */
  Dashboard.hasECharts = function () {
    return typeof window.echarts !== 'undefined';
  };

  /** پالت رنگ متن/محور بر اساس تم فعال */
  Dashboard.chartPalette = function () {
    const dark = document.documentElement.dataset.theme === 'dark';
    return {
      dark,
      fontFamily: "'Vazirmatn', 'Tahoma', sans-serif",
      text: dark ? '#d4d8dc' : '#21262b',
      muted: dark ? '#9aa0a7' : '#575e66',
      faint: dark ? '#6b7280' : '#878e95',
      splitLine: dark ? 'rgba(255,255,255,0.09)' : 'rgba(33,38,43,0.08)',
      axisLine: dark ? 'rgba(255,255,255,0.16)' : 'rgba(33,38,43,0.14)',
      tooltipBg: dark ? '#22262b' : '#fcfcfa',
      tooltipBorder: dark ? 'rgba(255,255,255,0.16)' : '#dcded2',
      // رنگ‌های کسب‌وکار — همان متغیرهای CSS
      raw: '#047857',      // زمردی
      metal: '#b45309',    // کهربایی
      setup: '#0f766e',    // فیروزه‌ای
      uncut: '#be123c',    // رز
      gray: dark ? '#7c848c' : '#a3a89e',
    };
  };

  /** ساخت/بازیابی نمونهٔ چارت با شناسهٔ المان */
  Dashboard.chartOf = function (elId) {
    const el = document.getElementById(elId);
    if (!el || !Dashboard.hasECharts()) return null;
    if (Dashboard._charts[elId]) return Dashboard._charts[elId];
    if (!el.clientWidth) return null;   // مخفی است — هنگام نمایش ساخته می‌شود
    const inst = window.echarts.init(el);
    Dashboard._charts[elId] = inst;
    return inst;
  };

  /** اعمال گزینه‌ها روی چارت (بدون Merge — رندر تازه) */
  Dashboard.applyChart = function (elId, option) {
    const inst = Dashboard.chartOf(elId);
    if (!inst) { Dashboard._pendingCharts = true; return false; }
    inst.setOption(option, { notMerge: true });
    return true;
  };

  /** حذف امن نمونهٔ چارت (حالت خالی — جلوگیری از نمونهٔ سرگردان) */
  Dashboard.disposeChart = function (elId) {
    if (Dashboard._charts[elId]) {
      try { Dashboard._charts[elId].dispose(); } catch (e) { /* noop */ }
      delete Dashboard._charts[elId];
    }
  };

  /** رندر مجدد همهٔ نمودارها (تعویض تم / بازگشت به تب) — نسخهٔ ۲٫۴:
      میله‌ای دستگاه‌ها + دو دونات زمان + نمودار ستونی ستاپ‌ها + نمودار افقی عرض‌ها (۳٫۱) */
  Dashboard.rerenderCharts = function () {
    if (!Dashboard._state) return;
    const s = Dashboard._state.summary;
    if (s.timeRulesCount) {
      Dashboard.renderMachineTimeChart(Dashboard._state);
      Dashboard.renderTimeDonuts(Dashboard._state);
      Dashboard.renderSetupInventoryColumnChart(Dashboard._state);
    }
    Dashboard.renderWidthInventoryChart(Dashboard._state);   // نسخهٔ ۳٫۱ — تغییر ۵
    Dashboard._pendingCharts = false;
  };

  /** هوک نمایش تب — نمودارهای معوق/تازه‌شده را رندر می‌کند */
  Dashboard.onShown = function () {
    // اگر المان مخفی بوده و چارت ساخته نشده → ساخت پس از نمایان شدن
    for (const id of Object.keys(Dashboard._charts)) {
      Dashboard._charts[id].resize();
    }
    Dashboard.rerenderCharts();
  };

  /* ---------- تغییر اندازهٔ پنجره → مقیاس‌دهی مجدد ---------- */
  let _resizeTimer = null;
  window.addEventListener('resize', () => {
    clearTimeout(_resizeTimer);
    _resizeTimer = setTimeout(() => {
      Object.values(Dashboard._charts).forEach((c) => { try { c.resize(); } catch (e) { /* noop */ } });
    }, 180);
  });

  /* ---------- تغییر تم → رنگ‌های نمودار تازه ---------- */
  if (typeof MutationObserver !== 'undefined') {
    const themeObserver = new MutationObserver(() => Dashboard.rerenderCharts());
    themeObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  }

  /** رندر کامل داشبورد از وضعیت محاسبه‌شده */
  Dashboard.render = async function (state) {
    Dashboard._state = state;   // برای Drill-down هشدارها و نمودارها
    const s = state.summary;

    /* مبنای ماندگار نمودار عرض‌ها + بستن دکمه‌ها (نسخهٔ ۳٫۱ — تغییر ۵) */
    await Dashboard.initWidthBasis();

    /* دستگاه‌های روشنِ ردیف میانگین ماتریس (نسخهٔ ۳٫۵ — تغییر ۴) */
    if (!Dashboard._avgMachines) {
      const saved = await RM.db.getSetting('matrixAvgMachines', null);
      Dashboard._avgMachines = Array.isArray(saved) && saved.length ? saved : null;   // null = همه روشن
    }

    /* ---------- کارت «رول‌های خام» (منطق جدید §58-§59 + نسخهٔ ۳٫۴ — تغییر ۳) ----------
       دو آمار کاربردی کلیک‌پذیر جایگزین اطلاعات قبلی کارت شد:
         ۱) تعداد رول‌های خام با گرید T → مودال لیست + پنل شخصی‌سازی ستون‌ها
         ۲) تعداد رول‌های تطبیق‌داده‌نشده با ستاپ‌ها → همان مودال */
    document.getElementById('kpi-raw').textContent = U.faNum(s.rawRollsCount);
    const rawActions = document.getElementById('kpi-raw-actions');
    if (rawActions) {
      rawActions.innerHTML = `
        <button type="button" class="kpi-act-row" data-raw-drill="gradeT"
                title="مشاهدهٔ رول‌های خام با گرید T به همراه مشخصات کامل">
          <span class="kpi-act-badge">T</span>
          <span class="kpi-act-label">رول های خام با گرید T</span>
          <b class="kpi-act-value">${U.faNum(s.rawGradeTCount)}</b>
          <span class="kpi-act-hint" aria-hidden="true">مشاهده ←</span>
        </button>
        <button type="button" class="kpi-act-row kpi-act-warn" data-raw-drill="unmatched"
                title="مشاهدهٔ رول‌هایی که با ستاپ‌ها تطبیق داده نشده‌اند">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
          <span class="kpi-act-label">رول هایی که ستاپ ندارند</span>
          <b class="kpi-act-value">${U.faNum(s.rawUnmatchedCount)}</b>
          <span class="kpi-act-hint" aria-hidden="true">مشاهده ←</span>
        </button>`;
      rawActions.querySelectorAll('[data-raw-drill]').forEach((btn) => {
        btn.addEventListener('click', () => Dashboard.openRawCardDrill(btn.dataset.rawDrill));
      });
    }

    /* ---------- کارت‌های مانده زمان متالایز (تغییرات جدید — جایگزین کارت‌های
       «رول‌های متالایز شده» و «کل رول‌های ستاپ‌ها») ---------- */
    if (!s.timeRulesCount) {
      // هیچ قانون زمانی تعریف نشده — کارت‌ها و چارت حالت خالی
      document.getElementById('kpi-remaining-setup').textContent = '—';
      document.getElementById('kpi-remaining-setup-meta').textContent =
        'قانون زمان متالایز تعریف نشده — از تنظیمات «قانون زمان متالایز» اضافه کنید.';
      document.getElementById('kpi-remaining-produced').textContent = '—';
      document.getElementById('kpi-remaining-produced-meta').textContent =
        'قانون زمان متالایز تعریف نشده — از تنظیمات «قانون زمان متالایز» اضافه کنید.';
      document.getElementById('machine-time-chips').innerHTML =
        '<span class="chip chip-warn">قانون زمان تعریف نشده</span>';
      Dashboard.disposeChart('machine-time-chart');
      document.getElementById('machine-time-footer').innerHTML = '';
      document.getElementById('machine-time-chart').innerHTML = `
        <div class="empty-state">
          ${UI.icons.alert}
          <p>برای نمایش گزارش مانده زمان متالایز، ابتدا در تب «تنظیمات» برای هر دستگاه قانون زمان تعریف کنید:<br>
          (شماره دستگاه، متراژ استاندارد، تعداد در شیفت → مدت زمان خودکار = ۷۲۰ ÷ تعداد)</p>
        </div>`;
      // دونات‌ها و نمودار ستونی نیز بدون قانون زمان محاسبه نمی‌شوند (نسخهٔ ۲٫۴)
      const emptyCharts = ['inventory-time-chart', 'setup-time-chart', 'setup-inventory-chart'];
      for (const id of emptyCharts) {
        Dashboard.disposeChart(id);
        const el = document.getElementById(id);
        if (el) el.innerHTML = `
          <div class="empty-state" style="min-height:220px">
            ${UI.icons.alert}
            <p>قانون زمان متالایز تعریف نشده — از تب «تنظیمات» قانون زمان اضافه کنید.</p>
          </div>`;
      }
    } else {
      document.getElementById('kpi-remaining-setup').textContent = U.hoursOf(s.totalRemainingSetupTime) !== null
        ? `${U.faNum(U.hoursOf(s.totalRemainingSetupTime))} ساعت`
        : '—';
      document.getElementById('kpi-remaining-setup-meta').innerHTML =
        `دقیق: ${U.faHMM(s.totalRemainingSetupTime)} · ` +
        `${U.faNum(s.timeRuleCoverage.covered)} رکورد دارای قانون` +
        (s.timeRuleCoverage.uncovered > 0
          ? ` · ⚠ ${U.faNum(s.timeRuleCoverage.uncovered)} رکورد بدون قانون`
          : '');

      document.getElementById('kpi-remaining-produced').textContent = U.hoursOf(s.totalRemainingProducedTime) !== null
        ? `${U.faNum(U.hoursOf(s.totalRemainingProducedTime))} ساعت`
        : '—';
      document.getElementById('kpi-remaining-produced-meta').innerHTML =
        `دقیق: ${U.faHMM(s.totalRemainingProducedTime)} · تفاوت با ستاپ: ${U.faHMM(
          s.totalRemainingSetupTime - s.totalRemainingProducedTime
        )} (زمان رول‌های متالایزشده)`;

      Dashboard.renderMachineTimeChart(state);

      /* ---------- دو دونات زمان (نسخهٔ ۲٫۴ — جایگزین دونات وضعیت خام) ---------- */
      Dashboard.renderTimeDonuts(state);

      /* ---------- نمودار ستونی مانده زمان موجودی همهٔ ستاپ‌ها (نسخهٔ ۲٫۴) ---------- */
      Dashboard.renderSetupInventoryColumnChart(state);
    }

    /* ---------- نمودار افقی عرض‌های رول (نسخهٔ ۳٫۱ — تغییر ۵) ----------
       مستقل از قوانین زمان — از ستون‌های خام موجود/تعداد گزارش ستاپ‌ها تغذیه می‌شود. */
    Dashboard.renderWidthInventoryChart(state);

    const uncutValue = document.getElementById('kpi-uncut');
    uncutValue.textContent = U.faNum(s.totalUncut);

    // فرمول شفاف برش‌نشده (§51 — مغایرت پنهان نمی‌شود)
    document.getElementById('kpi-uncut-meta').innerHTML =
      `Σ [ستاپ − (خام + متالایز)] = ${U.faNum(s.totalSetupRolls)} − ` +
      `(${U.faNum(s.rawMatchedCount)} + ${U.faNum(s.metallizedAllocated)})` +
      (s.totalConflict > 0
        ? `<br>⚠ مغایرت ظرفیت: ${U.faNum(s.totalConflict)} رول (در گزارش ستاپ‌ها)`
        : '');

    // حالت هشدار کارت برش‌نشده (مغایرت ظرفیت)
    const uncutCard = uncutValue.closest('.kpi-card');
    uncutCard.classList.toggle('negative', s.totalConflict > 0);

    /* ---------- کارت «رول‌های برش‌نشده» — ردیف کلیک‌پذیر (نسخهٔ ۳٫۵ — تغییر ۳) ----------
       مانند کارت «رول‌های خام»: با کلیک، رکوردهای «گزارش تولید ستاپ‌ها» که
       برش‌نشده دارند (uncut > 0) در مودال با پنل شخصی‌سازی ستون‌ها نمایش
       داده می‌شوند (فونت وزیر — انتخاب و ترتیب ماندگار). */
    const uncutActions = document.getElementById('kpi-uncut-actions');
    if (uncutActions) {
      const uncutSetupRows = (state.setupReport || []).filter((r) => r.uncut > 0);
      uncutActions.innerHTML = `
        <button type="button" class="kpi-act-row kpi-act-uncut" data-uncut-drill="1"
                title="مشاهدهٔ رکوردهای ستاپ‌های برش‌نشده به همراه مشخصات کامل">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>
          <span class="kpi-act-label">عرض های برش نشده ستاپ</span>
          <b class="kpi-act-value">${U.faNum(uncutSetupRows.length)}</b>
          <span class="kpi-act-hint" aria-hidden="true">مشاهده ←</span>
        </button>`;
      const uncutBtn = uncutActions.querySelector('[data-uncut-drill]');
      if (uncutBtn) uncutBtn.addEventListener('click', () => Dashboard.openUncutDrill());
    }

    /* ---------- مرکز هشدار کیفیت داده (§52 — B) ---------- */
    Dashboard.renderAlerts(state.warnings);

    /* ---------- اطلاعات فایل‌ها (§12) ---------- */
    await Dashboard.renderImportBadges();
  };

  /* ---------- Drill-down دو آمار کارت «رول‌های خام» (نسخهٔ ۳٫۴ — تغییر ۳) ----------
     هر دو از مودال مشترک با پنل شخصی‌سازی ستون‌های جزئیات استفاده می‌کنند. */
  Dashboard.openRawCardDrill = async function (kind) {
    try {
      if (kind === 'gradeT') {
        // رول‌های خام (نوع فیلم دارای R + پالت خالی) با گرید T — با اعمال ویرایش‌های کاربر
        const all = await RM.edits.applyToRecords('rolls', await db.rolls.toArray());
        const records = all.filter((r) => RM.normalize.isRawRoll(r) && RM.normalize.gradeLetter(r) === 'T');
        await UI.recordsDrillModal('رول‌های خام با گرید T', records, {
          source: 'rolls',
          subtitle: 'رول‌های خام (نوع فیلم دارای R + پالت خالی) با گرید T:',
        });
      } else {
        // رول‌های خامی که به هیچ ستاپی تخصیص نخورده‌اند (شناسه‌ها از موتور محاسبه)
        const state = Dashboard._state;
        const ids = (state && state.meta && state.meta.rawUnmatchedRollIds) || [];
        const got = ids.length ? await db.rolls.bulkGet(ids) : [];
        const records = await RM.edits.applyToRecords('rolls', got.filter(Boolean));
        await UI.recordsDrillModal('رول‌های خام تطبیق‌داده‌نشده با ستاپ‌ها', records, {
          source: 'rolls',
          subtitle: 'رول‌هایی که با ستاپ‌ها تطبیق داده نشده‌اند (گروه بدون ستاپ/قانون متراژ یا ظرفیت پر):',
        });
      }
    } catch (err) {
      console.error('[RawCardDrill]', err);
      UI.toast('نمایش رکوردهای این بخش با خطا مواجه شد.', 'error');
    }
  };

  /* ---------- Drill-down رکوردهای ستاپ‌های برش‌نشده (نسخهٔ ۳٫۵ — تغییر ۳) ----------
     رکوردهای «گزارش تولید ستاپ‌ها» با برش‌نشدهٔ مثبت، در جدول صفحه‌بندی‌شده
     با پنل شخصی‌سازی ستون‌ها (همان الگوی مودال‌های رکورد — چیپ‌های انتخاب و
     ترتیب، ماندگار در appSettings: uncutDrillColumns). */
  Dashboard.SETUP_DRILL_FIELDS = [
    { key: 'setupNumber',  label: 'ستاپ' },
    { key: 'machineNumber', label: 'دستگاه' },
    { key: 'width',        label: 'عرض' },
    { key: 'rollCount',    label: 'تعداد در ستاپ' },
    { key: 'rawExisting',  label: 'خام موجود' },
    { key: 'metallized',   label: 'متالایز' },
    { key: 'uncut',        label: 'برش‌نشده' },
    { key: 'conflict',     label: 'مغایرت ظرفیت' },
    { key: 'productionLine', label: 'خط تولید' },
    { key: 'hallNumber',   label: 'سالن' },
    { key: 'setupDate',    label: 'تاریخ ستاپ' },
    { key: 'thickness',    label: 'ضخامت' },
    { key: 'standardLength', label: 'متراژ استاندارد' },
    { key: 'remainingSetupTime', label: 'مانده زمان ستاپ' },
    { key: 'remainingProducedTime', label: 'مانده زمان موجودی' },
    { key: 'timeStatus',   label: 'وضعیت' },
  ];

  Dashboard.UNCUT_DRILL_DEFAULT = ['setupNumber', 'machineNumber', 'width', 'rollCount', 'rawExisting', 'metallized', 'uncut'];

  /** رندر سلول هر فیلد ستاپ در جدول دریل */
  Dashboard.setupDrillCell = function (r, key) {
    const v = r[key];
    switch (key) {
      case 'width': return v === null || v === undefined ? '<span class="muted">—</span>' : U.faWidth(v);
      case 'setupDate': return U.escapeHtml(U.faDateTime(v));
      case 'productionLine':
        return v
          ? `<span class="line-badge line-${U.escapeHtml(String(v).toLowerCase())}" title="خط تولید">${U.escapeHtml(String(v))}</span>`
          : '<span class="muted">—</span>';
      case 'remainingSetupTime':
      case 'remainingProducedTime':
        return v === null || v === undefined ? '<span class="muted">بدون قانون</span>' : U.faHMM(v);
      case 'timeStatus':
        return v === 'done' ? '<span class="pill-ok status-pill">تمام شده</span>'
          : v === 'remaining' ? '<span class="pill-bad status-pill">باقی مانده</span>'
          : '<span class="muted">نامشخص</span>';
      case 'uncut':
        return v > 0 ? `<b class="uncut-cell">${U.faNum(v)}</b>` : '<span class="muted">۰</span>';
      case 'conflict':
        return v > 0 ? `<span class="pill-bad status-pill">⚠ ${U.faNum(v)}</span>` : '—';
      default:
        return (v === null || v === undefined || v === '') ? '<span class="muted">—</span>' : U.faNum(v);
    }
  };

  /** تغییر ترتیب/انتخاب ستون‌های دریل ستاپ (خالص — با حداقل یک ستون) */
  Dashboard.applySetupDrillColumnsChange = function (current, key, action) {
    let next = [...current];
    const i = next.indexOf(key);
    if (action === 'on' && i === -1) next.push(key);
    else if (action === 'off' && i !== -1) next.splice(i, 1);
    else if (action === 'up' && i > 0) [next[i - 1], next[i]] = [next[i], next[i - 1]];
    else if (action === 'down' && i !== -1 && i < next.length - 1) [next[i + 1], next[i]] = [next[i], next[i + 1]];
    if (!next.length) next = [...Dashboard.UNCUT_DRILL_DEFAULT];
    return next;
  };

  /** پنل شخصی‌سازی ستون‌های دریل ستاپ (چیپ‌ها — همان الگوی مشترک مودال‌ها) */
  Dashboard.mountSetupDrillPicker = async function (mountEl, onChange) {
    if (!mountEl) return;
    const selected = await RM.db.getSetting('uncutDrillColumns', Dashboard.UNCUT_DRILL_DEFAULT)
      || [...Dashboard.UNCUT_DRILL_DEFAULT];

    // حفظ وضعیت باز/بستهٔ آکاردئون در رندرهای مجدد
    const prevDetails = mountEl.querySelector('details.detail-cols-picker');
    const prevOpen = !!(prevDetails && prevDetails.open);

    const labelOf = (k) => U.escapeHtml(
      (Dashboard.SETUP_DRILL_FIELDS.find((f) => f.key === k) || {}).label || k
    );
    const chip = (k, on) => on
      ? `<span class="detail-chip on">
           <button type="button" data-scol-up="${k}" title="انتقال به قبل" aria-label="انتقال به قبل">↑</button>
           <button type="button" data-scol-down="${k}" title="انتقال به بعد" aria-label="انتقال به بعد">↓</button>
           <b>${labelOf(k)}</b>
           <button type="button" data-scol-off="${k}" title="حذف ستون" aria-label="حذف ستون">×</button>
         </span>`
      : `<span class="detail-chip">
           <button type="button" data-scol-on="${k}" title="افزودن ستون" aria-label="افزودن ستون">+ ${labelOf(k)}</button>
         </span>`;

    const selectedSet = new Set(selected);
    mountEl.innerHTML =
      `<details class="detail-cols-picker"${prevOpen ? ' open' : ''}>
         <summary>ستون‌های جزئیات (انتخاب و ترتیب — ذخیره می‌شود)</summary>
         <div class="detail-chips">
           ${selected.map((k) => chip(k, true)).join('')}
           ${Dashboard.SETUP_DRILL_FIELDS.filter((f) => !selectedSet.has(f.key)).map((f) => chip(f.key, false)).join('')}
         </div>
       </details>`;

    const apply = async (key, action) => {
      const next = Dashboard.applySetupDrillColumnsChange(selected, key, action);
      await RM.db.setSetting('uncutDrillColumns', next);
      if (onChange) await onChange();
    };
    mountEl.querySelectorAll('[data-scol-on]').forEach((b) =>
      b.addEventListener('click', () => apply(b.dataset.scolOn, 'on')));
    mountEl.querySelectorAll('[data-scol-off]').forEach((b) =>
      b.addEventListener('click', () => apply(b.dataset.scolOff, 'off')));
    mountEl.querySelectorAll('[data-scol-up]').forEach((b) =>
      b.addEventListener('click', () => apply(b.dataset.scolUp, 'up')));
    mountEl.querySelectorAll('[data-scol-down]').forEach((b) =>
      b.addEventListener('click', () => apply(b.dataset.scolDown, 'down')));
  };

  /** مودال رکوردهای ستاپ‌های برش‌نشده (با پنل شخصی‌سازی ستون‌ها) */
  Dashboard.openUncutDrill = async function () {
    try {
      const state = Dashboard._state;
      const rows = (state && state.setupReport ? state.setupReport : [])
        .filter((r) => r.uncut > 0)
        .sort((a, b) => (a.setupNumber || 0) - (b.setupNumber || 0) || (a.width || 0) - (b.width || 0));
      const totalUncut = rows.reduce((s, r) => s + r.uncut, 0);

      UI.infoModal('ستاپ‌های برش‌نشده', `
        <div class="drill-subtitle">
          رکوردهای «گزارش تولید ستاپ‌ها» با رول برش‌نشده — فرمول: تعداد − (خام موجود + متالایز):
          <b>${U.faNum(rows.length)}</b> رکورد · جمع برش‌نشده: <b>${U.faNum(totalUncut)}</b> رول
        </div>
        <div id="uncut-cols-picker"></div>
        <div id="uncut-table-wrap"></div>
      `);

      const renderTable = async () => {
        const selected = await RM.db.getSetting('uncutDrillColumns', Dashboard.UNCUT_DRILL_DEFAULT)
          || [...Dashboard.UNCUT_DRILL_DEFAULT];
        const columns = selected
          .filter((k) => Dashboard.SETUP_DRILL_FIELDS.some((f) => f.key === k))
          .map((k) => ({
            key: k,
            label: U.escapeHtml((Dashboard.SETUP_DRILL_FIELDS.find((f) => f.key === k) || {}).label || k),
            className: k === 'uncut' ? 'em-cell' : '',
            render: (r) => Dashboard.setupDrillCell(r, k),
          }));
        const renderPage = (page) => {
          UI.renderTable(document.getElementById('uncut-table-wrap'), columns, rows, {
            page,
            pageSize: RM.config.PAGE_SIZE,
            emptyText: 'رکوردی برای نمایش یافت نشد.',
            onPageChange: (nextPage) => renderPage(nextPage),
          });
        };
        renderPage(1);
      };

      const mountPicker = async () => {
        await Dashboard.mountSetupDrillPicker(
          document.getElementById('uncut-cols-picker'),
          async () => {
            await mountPicker();
            await renderTable();
          }
        );
      };
      await mountPicker();
      await renderTable();
    } catch (err) {
      console.error('[UncutDrill]', err);
      UI.toast('نمایش رکوردهای این بخش با خطا مواجه شد.', 'error');
    }
  };

  /* ---------- چارت مانده زمان متالایز به تفکیک دستگاه (نسخهٔ ۲٫۳ — ECharts) ---------- */

  /**
   * نمودار میله‌ای افقی گروهی ECharts — هر دستگاه (۱/۲/۳) دو میله:
   *   «مانده زمان ستاپ» (فیروزه‌ای) و «مانده زمان موجودی» (کهربایی).
   * نسخهٔ ۲٫۵ — راست‌به‌چپ: نام دستگاه‌ها در سمت راست (yAxis position:right)
   * و میله‌ها از راست (کنار نام‌ها) به چپ رشد می‌کنند (xAxis inverse).
   * Tooltip فارسی با مدت دقیق + برچسب ساعت روی محور. Fallback: میله‌های CSS.
   * زیر نمودار: آمار دوخطی (کمترین دستگاه + میانگین) — نسخهٔ ۲٫۴.
   */
  Dashboard.renderMachineTimeChart = function (state) {
    const s = state.summary;
    const machines = RM.config.VALID_MACHINES;

    // بیشینه برای مقیاس
    let maxVal = 0;
    for (const m of machines) {
      const t = s.machineTime[m];
      if (t) maxVal = Math.max(maxVal, t.setup, t.produced);
    }

    const chipsEl = document.getElementById('machine-time-chips');
    chipsEl.innerHTML = `
      <span class="chip">قوانین زمان: ${U.faNum(s.timeRulesCount)}</span>
      <span class="chip chip-strong">جمع مانده زمان ستاپ: ${U.faHMM(s.totalRemainingSetupTime)}</span>
      <span class="chip chip-ok">جمع مانده زمان موجودی: ${U.faHMM(s.totalRemainingProducedTime)}</span>
      ${s.timeRuleCoverage.uncovered > 0
        ? `<span class="chip chip-warn">${U.faNum(s.timeRuleCoverage.uncovered)} رکورد بدون قانون</span>`
        : ''}
    `;

    /* ---------- جدول ماتریسی مانده زمان زیر نمودار (نسخهٔ ۳٫۴ — تغییر ۲) ----------
       دو ستون × دو ردیف — دقیقاً چیدمان خواسته‌شدهٔ کاربر:
         ستون‌ها: «رول‌های موجود» (مانده زمان موجودی — کهربایی، هماهنگ با چارت)
                  «رول‌های ستاپ»  (مانده زمان ستاپ — فیروزه‌ای، هماهنگ با چارت)
         ردیف‌ها: «کمترین مانده زمان» (دستگاه دارای کمترین مانده زمان موجودی)
                  «میانگین دستگاه‌ها» (جمع ÷ تعداد دستگاه‌ها)
       هر سلول: مقدار [H]:mm درشت + «معادل روزانه: X روز» — طراحی کارت‌ماتریسی
       کاربرپسند با هدرهای رنگی و اعداد فارسی خوانا در یک نگاه.
       نسخهٔ ۳٫۵ — تغییر ۴: در ردیف «میانگین دستگاه‌ها» آیکون‌های ریز کلیک‌پذیر
       دستگاه‌ها درج شد — میانگین هر دو ستون فقط از دستگاه‌های روشن محاسبه
       می‌شود (مثلاً دستگاه ۱ و ۳ روشن → جمع مقادیرشان ÷ ۲). انتخاب ماندگار
       است (appSettings: matrixAvgMachines). */
    const producedOf = (m) => (s.machineTime[m] ? s.machineTime[m].produced : 0);
    const setupOf = (m) => (s.machineTime[m] ? s.machineTime[m].setup : 0);
    let minMachine = machines[0];
    let minProduced = Infinity;
    for (const m of machines) {
      if (producedOf(m) < minProduced) { minProduced = producedOf(m); minMachine = m; }
    }

    const mtCell = (minutes, cls) => `
      <div class="mtx-cell ${cls}">
        <span class="mtx-value">${U.faHMM(minutes)}</span>
        <span class="mtx-days">معادل روزانه: ${U.faDaysOf(minutes)}</span>
      </div>`;

    /* ماتریس با آیکون‌های دستگاه + میانگینِ دستگاه‌های روشن (رندر مجدد بدون چارت) */
    const renderMatrix = () => {
      const avgOn = Dashboard._avgMachines && Dashboard._avgMachines.length
        ? Dashboard._avgMachines.filter((m) => machines.includes(m))
        : [...machines];   // پیش‌فرض: همهٔ دستگاه‌ها روشن
      const machineCount = avgOn.length;
      const sumProduced = avgOn.reduce((acc, m) => acc + producedOf(m), 0);
      const sumSetup = avgOn.reduce((acc, m) => acc + setupOf(m), 0);
      const avgProduced = machineCount ? sumProduced / machineCount : 0;
      const avgSetup = machineCount ? sumSetup / machineCount : 0;

      document.getElementById('machine-time-footer').innerHTML = `
        <div class="mt-matrix" role="table" aria-label="مانده زمان متالایز — کمترین و میانگین به تفکیک رول‌های موجود و رول‌های ستاپ">
          <div class="mtx-row mtx-head" role="row">
            <span class="mtx-corner" role="columnheader"></span>
            <span class="mtx-colhead mtx-col-inv" role="columnheader">
              <span class="mtx-dot mtx-dot-inv" aria-hidden="true"></span> رول‌های موجود
            </span>
            <span class="mtx-colhead mtx-col-setup" role="columnheader">
              <span class="mtx-dot mtx-dot-setup" aria-hidden="true"></span> رول‌های ستاپ
            </span>
          </div>
          <div class="mtx-row" role="row">
            <span class="mtx-rowhead" role="rowheader">
              کمترین مانده زمان
              <span class="mtx-sub">دستگاه ${U.faNum(minMachine)}</span>
            </span>
            ${mtCell(producedOf(minMachine), 'mtx-inv')}
            ${mtCell(setupOf(minMachine), 'mtx-setup')}
          </div>
          <div class="mtx-row" role="row">
            <span class="mtx-rowhead" role="rowheader">
              میانگین دستگاه‌ها
              <span class="mtx-sub">${machineCount ? `${U.faNum(machineCount)} دستگاه` : 'دستگاهی انتخاب نشده'}</span>
              <span class="mtx-mach-btns" role="group" aria-label="انتخاب دستگاه‌های شرکت‌کننده در میانگین">
                ${machines.map((m) => `
                  <button type="button" class="mtx-mach${avgOn.includes(m) ? ' on' : ''}" data-mtx-mach="${m}"
                          aria-pressed="${avgOn.includes(m) ? 'true' : 'false'}"
                          title="${avgOn.includes(m)
                            ? `دستگاه ${U.faNum(m)} در میانگین است — برای حذف از میانگین کلیک کنید`
                            : `دستگاه ${U.faNum(m)} در میانگین نیست — برای افزودن به میانگین کلیک کنید`}">
                    <span class="mtx-mach-num">${U.faNum(m)}</span>
                  </button>`).join('')}
              </span>
            </span>
            ${machineCount
              ? mtCell(avgProduced, 'mtx-inv') + mtCell(avgSetup, 'mtx-setup')
              : `<div class="mtx-cell mtx-inv"><span class="mtx-value muted">—</span><span class="mtx-days">دستگاهی روشن نیست</span></div>
                 <div class="mtx-cell mtx-setup"><span class="mtx-value muted">—</span><span class="mtx-days">دستگاهی روشن نیست</span></div>`}
          </div>
        </div>`;

      // کلیدهای ریز دستگاه — روشن/خاموش + ذخیرهٔ ماندگار + محاسبهٔ مجدد
      document.querySelectorAll('[data-mtx-mach]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const m = Number(btn.dataset.mtxMach);
          const current = Dashboard._avgMachines && Dashboard._avgMachines.length
            ? [...Dashboard._avgMachines]
            : [...machines];
          const i = current.indexOf(m);
          if (i !== -1) current.splice(i, 1);
          else current.push(m);
          Dashboard._avgMachines = current;
          await RM.db.setSetting('matrixAvgMachines', current);
          renderMatrix();
          UI.toast(
            current.includes(m)
              ? `دستگاه ${U.faNum(m)} به میانگین اضافه شد.`
              : `دستگاه ${U.faNum(m)} از میانگین حذف شد.`,
            'info', 1800
          );
        });
      });
    };
    renderMatrix();

    if (!Dashboard.hasECharts()) {
      Dashboard.renderMachineTimeChartFallback(state);   // کتابخانه در دسترس نیست
      return;
    }

    const P = Dashboard.chartPalette();
    const cats = machines.map((m) => `دستگاه ${U.faNumPlain(m)}`).reverse();   // دستگاه ۱ بالا
    const setupData = machines.map((m) => {
      const t = s.machineTime[m];
      return t && t.setup ? t.setup : 0;
    }).reverse();
    const producedData = machines.map((m) => {
      const t = s.machineTime[m];
      return t && t.produced ? t.produced : 0;
    }).reverse();
    const recordsByMachine = machines.map((m) => {
      const t = s.machineTime[m];
      return t ? t.records : 0;
    }).reverse();

    const option = {
      animationDuration: 550,
      animationEasing: 'cubicOut',
      textStyle: { fontFamily: P.fontFamily },
      // نسخهٔ ۲٫۵: راست‌به‌چپ — میله‌ها از راست (کنار نام دستگاه‌ها) به چپ رشد می‌کنند
      grid: { left: 56, right: 8, top: 42, bottom: 8, containLabel: true },
      legend: {
        top: 4,
        right: 8,
        itemWidth: 14,
        itemHeight: 9,
        itemGap: 18,
        textStyle: { color: P.muted, fontFamily: P.fontFamily, fontSize: 11 },
        data: ['مانده زمان ستاپ', 'مانده زمان موجودی'],
      },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow', shadowStyle: { color: P.splitLine } },
        backgroundColor: P.tooltipBg,
        borderColor: P.tooltipBorder,
        borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: P.text, fontFamily: P.fontFamily, fontSize: 12 },
        formatter: (params) => {
          const idx = params[0] ? params[0].dataIndex : 0;
          const m = RM.config.VALID_MACHINES[machines.length - 1 - idx] || '—';
          const lines = [`<b>دستگاه ${U.faNumPlain(m)}</b> · ${U.faNum(recordsByMachine[idx] || 0)} رکورد`];
          for (const p of params) {
            lines.push(`${p.marker} ${p.seriesName}: <b>${U.faDuration(p.value)}</b>${p.value ? ` (~${U.faNum(Math.round(p.value / 60))} ساعت)` : ''}`);
          }
          return lines.join('<br>');
        },
      },
      xAxis: {
        type: 'value',
        inverse: true,                       // نسخهٔ ۲٫۵: صفر در راست → رشد به چپ
        max: (v) => Math.max(v.max * 1.08, 60),
        axisLabel: {
          color: P.muted,
          fontFamily: P.fontFamily,
          fontSize: 10.5,
          formatter: (v) => `${U.faNumPlain(Math.round(v / 60))} ساعت`,
        },
        splitLine: { lineStyle: { color: P.splitLine, width: 1 } },
        axisLine: { show: false },
        axisTick: { show: false },
      },
      yAxis: {
        type: 'category',
        position: 'right',                  // نسخهٔ ۲٫۵: نام دستگاه‌ها در سمت راست
        data: cats,
        axisLabel: { color: P.text, fontFamily: P.fontFamily, fontSize: 12, fontWeight: 600 },
        axisLine: { lineStyle: { color: P.axisLine } },
        axisTick: { show: false },
      },
      series: [
        {
          name: 'مانده زمان ستاپ',
          type: 'bar',
          data: setupData,
          barMaxWidth: 18,
          barGap: '28%',
          itemStyle: { color: P.setup, borderRadius: [4, 0, 0, 4] },
          emphasis: { itemStyle: { color: P.setup, opacity: 0.82 } },
          label: {
            show: true,
            position: 'left',              // نسخهٔ ۲٫۵: نوک میله (سمت چپ — رشد راست‌به‌چپ)
            // نسخهٔ ۲٫۶: بولد‌تر + تم‌آگاه (تاریک → روشن، روشن → سیاه)
            color: P.dark ? '#e8ebef' : '#15181c',
            fontFamily: P.fontFamily,
            fontSize: 10.5,
            fontWeight: 700,
            formatter: (p) => (p.value ? `${U.faNumPlain(Math.round(p.value / 60))} ساعت` : ''),
          },
        },
        {
          name: 'مانده زمان موجودی',
          type: 'bar',
          data: producedData,
          barMaxWidth: 18,
          itemStyle: { color: P.metal, borderRadius: [4, 0, 0, 4] },
          emphasis: { itemStyle: { color: P.metal, opacity: 0.82 } },
          label: {
            show: true,
            position: 'left',              // نسخهٔ ۲٫۵: نوک میله (سمت چپ — رشد راست‌به‌چپ)
            // نسخهٔ ۲٫۶: بولد‌تر + تم‌آگاه (تاریک → روشن، روشن → سیاه)
            color: P.dark ? '#e8ebef' : '#15181c',
            fontFamily: P.fontFamily,
            fontSize: 10.5,
            fontWeight: 700,
            formatter: (p) => (p.value ? `${U.faNumPlain(Math.round(p.value / 60))} ساعت` : ''),
          },
        },
      ],
    };

    Dashboard.applyChart('machine-time-chart', option);
  };

  /* ---------- دو دونات زمان متالایز (نسخهٔ ۲٫۴ — جایگزین دونات وضعیت خام) ----------
     زیر نمودار میله‌ای، دو دونات قرار می‌گیرد:
       ۱) دونات «مانده زمان موجودی» — سهم هر سه دستگاه + متن مرکزی دوخطی:
          بالا «کمترین: [H]:mm» و پایین «میانگین: [H]:mm»
       ۲) دونات «مانده زمان ستاپ» — همان ساختار با زمان‌های ستاپ
     میانگین = جمع دستگاه‌ها ÷ تعداد دستگاه‌ها.
     نسخهٔ ۲٫۵: مرکز دونات = مرکز بوم (center ۵۰٪/۵۰٪) و متن مرکزی با
     top:'middle' دقیقاً وسط‌چین می‌شود — مابین دو خط «کمترین/میانگین».
     نسخهٔ ۲٫۶: رنگ دستگاه‌ها پررنگ‌تر (۱=#82C836 · ۲=#F09252 · ۳=#00C1EE) و
     متن مرکزی بولد با فونت تطبیقی — همیشه داخل حفرهٔ مرکز (بیرون نمی‌زند).
     تغییر ۴: لیبل‌های «کمترین/میانگین» مرکز دونات بزرگ‌تر و بولد (هم‌اندازهٔ
     فونت ستون‌های تأکیدی جدول‌ها — 16px/700) + دیتالیبل هر دستگاه کمی
     بزرگ‌تر، بولد و مطلق (روشن → سیاه مطلق #000000 · تاریک → سفید مطلق
     #ffffff برای خوانایی). */

  /** ساخت و اعمال یک دونات زمان (سهم دستگاه‌ها + مرکز دوخطی کمترین/میانگین) */
  Dashboard.timeDonutOption = function (P, values, metricLabel, boxSize) {
    const machines = RM.config.VALID_MACHINES;
    const total = values.reduce((a, b) => a + b, 0);
    const minVal = Math.min(...values);
    const avgVal = total / machines.length;

    /* فونت تطبیقی متن مرکزی (تغییر ۴): بر اساس ابعاد واقعی بوم، اندازه‌ای
       هم‌اندازهٔ فونت ستون‌های تأکیدی جدول‌ها (em-cell: 16px/700) انتخاب
       می‌شود؛ اگر متن در حفرهٔ مرکز (حاشیهٔ امن ۱۲px) جا نشود کم می‌شود
       اما هرگز از 11px کوچک‌تر نمی‌شود. */
    const minDim = boxSize && (boxSize.w || boxSize.h)
      ? Math.max(180, Math.min(boxSize.w || 320, boxSize.h || 320))
      : 320;
    const innerR = (minDim / 2) * 0.54;                    // شعاع داخلی دونات (px)
    let fs = Math.max(12, Math.min(16, innerR * 0.2));
    const maxChars = Math.max(
      `کمترین: ${U.faHMM(minVal)}`.length,
      `میانگین: ${U.faHMM(avgVal)}`.length
    );
    const maxW = innerR * 2 - 12;                          // عرض مجاز داخل حفره
    while (fs > 11 && maxChars * 0.62 * fs > maxW) fs -= 0.5;

    return {
      animationDuration: 550,
      textStyle: { fontFamily: P.fontFamily },
      tooltip: {
        trigger: 'item',
        backgroundColor: P.tooltipBg,
        borderColor: P.tooltipBorder,
        borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: P.text, fontFamily: P.fontFamily, fontSize: 12 },
        formatter: (p) => `<b>${p.name}</b> — ${metricLabel}<br>${U.faHMM(p.value)}${
          p.value ? ` (~${U.faNumPlain(Math.round(p.value / 60))} ساعت · ${U.faDaysOf(p.value)})` : ''}`,
      },
      legend: {
        bottom: 2,
        left: 'center',
        itemWidth: 12,
        itemHeight: 12,
        itemGap: 14,
        textStyle: { color: P.muted, fontFamily: P.fontFamily, fontSize: 11 },
      },
      series: [
        {
          type: 'pie',
          radius: ['54%', '74%'],
          center: ['50%', '50%'],   // نسخهٔ ۲٫۵: مرکز دونات = مرکز بوم → متن مرکزی دقیقاً وسط
          avoidLabelOverlap: true,
          itemStyle: { borderColor: P.dark ? '#16181b' : '#fcfcfa', borderWidth: 2 },
          label: {
            /* تغییر ۴: دیتالیبل هر دستگاه — کمی بزرگ‌تر، بولد، مطلق:
               تم روشن → سیاه مطلق #000000 · تم تاریک → سفید مطلق #ffffff (خوانایی) */
            show: true,
            color: P.dark ? '#ffffff' : '#000000',
            fontFamily: P.fontFamily,
            fontSize: 12,
            fontWeight: 700,
            formatter: (p) => (p.value ? U.faHMM(p.value) : ''),   // نسخهٔ ۲٫۵: برچسب مقدار صفر مخفی
          },
          emphasis: {
            scale: true,
            scaleSize: 5,
            label: { show: true, fontWeight: 700, color: P.dark ? '#ffffff' : '#000000' },
          },
          data: machines.map((m, i) => ({
            name: `دستگاه ${U.faNumPlain(m)}`,
            value: values[i],
            itemStyle: { color: RM.config.MACHINE_COLORS[m] || P.setup },
          })),
        },
      ],
      graphic: [
        {
          type: 'text',
          left: 'center',
          top: 'middle',              // نسخهٔ ۲٫۵: دقیقاً مرکز بوم = مرکز دونات
          style: {
            /* تغییر ۴: دو خط بزرگ و بولد — هم‌اندازهٔ فونت ستون «عرض (mm)»
               جدول رول‌های خام (em-cell: 16px/700)؛ fontSize تطبیقی همیشه
               داخل حفرهٔ مرکز می‌ماند. */
            text: `{lbl|کمترین: }{v|${U.faHMM(minVal)}}\n{lbl|میانگین: }{v|${U.faHMM(avgVal)}}`,
            rich: {
              lbl: {
                fontSize: fs,
                fontWeight: 700,
                color: P.text,
                fontFamily: P.fontFamily,
              },
              v: {
                fontSize: Math.min(18, fs + 2),
                fontWeight: 800,
                color: P.text,
                fontFamily: P.fontFamily,
              },
            },
            fontSize: fs,
            fontFamily: P.fontFamily,
            textAlign: 'center',
            textVerticalAlign: 'middle',
            fill: P.text,
            lineHeight: Math.round(fs * 1.8),
          },
        },
      ],
    };
  };

  /** رندر دو دونات «مانده زمان موجودی» و «مانده زمان ستاپ» */
  Dashboard.renderTimeDonuts = function (state) {
    const s = state.summary;
    const machines = RM.config.VALID_MACHINES;
    const producedValues = machines.map((m) => (s.machineTime[m] ? s.machineTime[m].produced : 0));
    const setupValues = machines.map((m) => (s.machineTime[m] ? s.machineTime[m].setup : 0));

    const hasAny = producedValues.some((v) => v > 0) || setupValues.some((v) => v > 0);
    if (!hasAny) {
      const emptyHtml = `
        <div class="empty-state" style="min-height:220px">
          ${UI.icons.alert}
          <p>هنوز رکوردی با قانون زمان متالایز تطبیق نشده — دونات‌ها پس از تطبیق رکوردها رندر می‌شوند.</p>
        </div>`;
      for (const id of ['inventory-time-chart', 'setup-time-chart']) {
        Dashboard.disposeChart(id);
        const el = document.getElementById(id);
        if (el) el.innerHTML = emptyHtml;
      }
      return;
    }

    if (!Dashboard.hasECharts()) {
      // Fallback: چیپ‌های متنی هر دستگاه
      const rowsHtml = (vals) => machines.map((m, i) =>
        `<div class="mt-row"><div class="mt-label"><b style="color:${RM.config.MACHINE_COLORS[m]}">دستگاه ${U.faNum(m)}</b></div><b>${U.faHMM(vals[i])}</b></div>`
      ).join('');
      const inv = document.getElementById('inventory-time-chart');
      const stp = document.getElementById('setup-time-chart');
      if (inv) inv.innerHTML = `<div class="mt-rows" style="padding:12px">${rowsHtml(producedValues)}</div>`;
      if (stp) stp.innerHTML = `<div class="mt-rows" style="padding:12px">${rowsHtml(setupValues)}</div>`;
      return;
    }

    const P = Dashboard.chartPalette();
    /* ابعاد واقعی بوم‌ها → فونت تطبیقی متن مرکزی (نسخهٔ ۲٫۶) */
    const boxOf = (id) => {
      const el = document.getElementById(id);
      return el ? { w: el.clientWidth, h: el.clientHeight } : { w: 0, h: 0 };
    };
    Dashboard.applyChart('inventory-time-chart',
      Dashboard.timeDonutOption(P, producedValues, 'مانده زمان موجودی', boxOf('inventory-time-chart')));
    Dashboard.applyChart('setup-time-chart',
      Dashboard.timeDonutOption(P, setupValues, 'مانده زمان ستاپ', boxOf('setup-time-chart')));
  };

  /* ---------- نمودار ستونی مانده زمان موجودی همهٔ ستاپ‌ها (نسخهٔ ۲٫۴ / ۲٫۵) ----------
     نسخهٔ ۲٫۵: به‌ازای هر ستاپ (شماره ستاپ) فقط یک میله — مجموع مانده زمان
     موجودی همهٔ رکوردهای همان شماره ستاپ (Σ [خام موجود × مدت] — نسخهٔ ۲٫۷).
     رکوردهای بدون قانون زمان در مجموع لحاظ نمی‌شوند (Tooltip اعلام می‌کند).
     تغییر ۵: دیتالیبل هر ستون کمی بزرگ‌تر، بولد و مطلق (روشن → سیاه مطلق
     #000000 · تاریک → سفید مطلق #ffffff برای خوانایی). */

  Dashboard.renderSetupInventoryColumnChart = function (state) {
    const report = state.setupReport;
    const el = document.getElementById('setup-inventory-chart');
    if (!el) return;

    if (!report.length) {
      Dashboard.disposeChart('setup-inventory-chart');
      el.innerHTML = `
        <div class="empty-state" style="min-height:220px">
          ${UI.icons.alert}
          <p>هنوز ستاپی ثبت نشده — هر ستاپ (شماره ستاپ) یک میله از مجموع مانده زمان موجودی رکوردهایش خواهد بود.</p>
        </div>`;
      return;
    }

    // مرتب‌سازی رکوردها: شماره ستاپ → دستگاه → عرض
    const sorted = [...report].sort((a, b) =>
      (a.setupNumber - b.setupNumber) ||
      (a.machineNumber - b.machineNumber) ||
      (a.width - b.width));

    // گروه‌بندی بر اساس شماره ستاپ — یک میله برای هر ستاپ (نسخهٔ ۲٫۵)
    const groups = [];
    const bySetup = new Map();
    for (const r of sorted) {
      let g = bySetup.get(r.setupNumber);
      if (!g) {
        g = { setupNumber: r.setupNumber, records: [], total: 0, noRuleCount: 0 };
        bySetup.set(r.setupNumber, g);
        groups.push(g);
      }
      g.records.push(r);
      if (r.remainingProducedTime === null) {
        g.noRuleCount++;                       // رکورد بدون قانون زمان
      } else {
        g.total += r.remainingProducedTime;    // Σ [خام موجود × مدت] (نسخهٔ ۲٫۷)
      }
    }

    const values = groups.map((g) => g.total);

    if (!Dashboard.hasECharts()) {
      // Fallback: فهرست متنی — یک ردیف برای هر ستاپ (مجموع)
      el.innerHTML = `
        <div class="mt-rows" style="padding:12px; max-height:320px; overflow:auto">
          ${groups.map((g) => `<div class="mt-row"><div class="mt-label"><b>ستاپ ${U.faNum(g.setupNumber)}</b> · ${U.faNum(g.records.length)} رکورد</div><b>${U.faHMM(g.total)}</b></div>`).join('')}
        </div>`;
      return;
    }

    const P = Dashboard.chartPalette();
    const showLabels = groups.length <= 14;

    const option = {
      animationDuration: 550,
      textStyle: { fontFamily: P.fontFamily },
      grid: { left: 10, right: 16, top: 26, bottom: 8, containLabel: true },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow', shadowStyle: { color: P.splitLine } },
        backgroundColor: P.tooltipBg,
        borderColor: P.tooltipBorder,
        borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: P.text, fontFamily: P.fontFamily, fontSize: 12 },
        // نسخهٔ ۲٫۶: فقط ستاپ + مانده زمان موجودی — جزئیات رکوردها حذف شد
        formatter: (params) => {
          const p = params[0];
          if (!p) return '';
          const g = groups[p.dataIndex];
          return `<b>ستاپ ${U.faNum(g.setupNumber)}</b><br>مانده زمان موجودی: <b>${U.faHMM(p.value)}</b>`;
        },
      },
      xAxis: {
        type: 'category',
        data: groups.map((g) => U.faNumPlain(g.setupNumber)),
        axisLabel: {
          color: P.muted,
          fontFamily: P.fontFamily,
          fontSize: 10.5,
          hideOverlap: true,
          interval: 'auto',
        },
        axisLine: { lineStyle: { color: P.axisLine } },
        axisTick: { show: false },
        name: 'شماره ستاپ',
        nameLocation: 'middle',
        nameGap: 26,
        nameTextStyle: { color: P.faint, fontFamily: P.fontFamily, fontSize: 10.5 },
      },
      yAxis: {
        type: 'value',
        max: (v) => Math.max(v.max * 1.12, 60),
        axisLabel: {
          color: P.muted,
          fontFamily: P.fontFamily,
          fontSize: 10.5,
          formatter: (v) => `${U.faNumPlain(Math.round(v / 60))} ساعت`,
        },
        splitLine: { lineStyle: { color: P.splitLine, width: 1 } },
        axisLine: { show: false },
        axisTick: { show: false },
      },
      series: [
        {
          name: 'مانده زمان موجودی',
          type: 'bar',
          data: values,
          barMaxWidth: 34,
          itemStyle: { color: P.metal, borderRadius: [5, 5, 0, 0] },
          emphasis: { itemStyle: { color: P.metal, opacity: 0.82 } },
          label: showLabels
            ? {
                /* تغییر ۵: دیتالیبل هر ستون — کمی بزرگ‌تر، بولد، مطلق:
                   تم روشن → سیاه مطلق #000000 · تم تاریک → سفید مطلق #ffffff (خوانایی) */
                show: true,
                position: 'top',
                color: P.dark ? '#ffffff' : '#000000',
                fontFamily: P.fontFamily,
                fontSize: 11.5,
                fontWeight: 700,
                formatter: (p) => (p.value ? U.faHMM(p.value) : ''),
              }
            : { show: false },
        },
      ],
    };

    Dashboard.applyChart('setup-inventory-chart', option);
  };

  /* ---------- نمودار افقی عرض‌های رول (نسخهٔ ۳٫۱ — تغییر ۵) ----------
     هر میله یک «عرض» از رکوردهای جدول «گزارش تولید ستاپ‌ها» است:
       · مبنای پیش‌فرض = ستون «خام موجود» → فقط عرض‌هایی نمایش داده می‌شوند
         که رول خام موجود (مقدار مثبت) دارند؛ طول میله = مجموع خام موجود همان عرض
       · مبنای جایگزین (انتخاب کاربر کنار نمودار) = ستون «تعداد» → همهٔ عرض‌های
         دارای تعداد مثبت؛ طول میله = مجموع تعداد همان عرض
       · مرتب‌سازی: از عرض بزرگ به کوچک (بالا → پایین)
       · روی هر میله تعداد رول همان عرض درج می‌شود؛ محور راست = اندازهٔ عرض.
     انتخاب مبنا ماندگار است (appSettings: dashboardWidthChartBasis). */

  Dashboard._widthBasis = null;         // 'rawExisting' (پیش‌فرض) | 'rollCount'
  Dashboard._widthBasisBound = false;   // دکمه‌های مبنا یک‌بار بسته می‌شوند
  Dashboard._widthMachine = 'all';      // فیلتر دستگاه (نسخهٔ ۳٫۵ — تغییر ۲): 'all' | 1|2|3
  Dashboard._widthMachineBound = false;

  /** بارگذاری مبنای ماندگار + بستن دکمه‌های سگمنتی (یک‌بار) */
  Dashboard.initWidthBasis = async function () {
    if (Dashboard._widthBasis === null) {
      Dashboard._widthBasis = await RM.db.getSetting('dashboardWidthChartBasis', 'rawExisting');
    }
    if (Dashboard._widthMachine === 'all' || Dashboard._widthMachine === null) {
      const savedMachine = await RM.db.getSetting('dashboardWidthChartMachine', 'all');
      Dashboard._widthMachine = (savedMachine === 1 || savedMachine === 2 || savedMachine === 3)
        ? savedMachine
        : 'all';
    }
    if (!Dashboard._widthBasisBound) {
      Dashboard._widthBasisBound = true;
      const seg = document.getElementById('width-basis-seg');
      if (seg) {
        seg.querySelectorAll('.seg-btn').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const next = btn.dataset.basis === 'rollCount' ? 'rollCount' : 'rawExisting';
            if (next === Dashboard._widthBasis) return;
            Dashboard._widthBasis = next;
            await RM.db.setSetting('dashboardWidthChartBasis', next);
            Dashboard.applyWidthBasisUi();
            if (Dashboard._state) Dashboard.renderWidthInventoryChart(Dashboard._state);
          });
        });
      }
    }
    /* فیلتر دستگاه (نسخهٔ ۳٫۵ — تغییر ۲): انتخابگر کنار سگمنت مبنا —
       با انتخاب دستگاه، فقط رکوردهای گزارش ستاپ‌های همان دستگاه در
       گروه‌بندی عرض‌ها می‌آیند (رول‌های خام اختصاص‌یافته به آن دستگاه). */
    if (!Dashboard._widthMachineBound) {
      Dashboard._widthMachineBound = true;
      const sel = document.getElementById('width-machine-select');
      if (sel) {
        sel.value = String(Dashboard._widthMachine);
        sel.addEventListener('change', async () => {
          const v = sel.value === '1' || sel.value === '2' || sel.value === '3'
            ? Number(sel.value) : 'all';
          Dashboard._widthMachine = v;
          await RM.db.setSetting('dashboardWidthChartMachine', v);
          Dashboard.applyWidthBasisUi();
          if (Dashboard._state) Dashboard.renderWidthInventoryChart(Dashboard._state);
        });
      }
    }
    Dashboard.applyWidthBasisUi();
  };

  /** همگام‌سازی ظاهر سگمنتی/عنوان با مبنای فعال + فیلتر دستگاه */
  Dashboard.applyWidthBasisUi = function () {
    const basis = Dashboard._widthBasis === 'rollCount' ? 'rollCount' : 'rawExisting';
    const seg = document.getElementById('width-basis-seg');
    if (seg) {
      seg.querySelectorAll('.seg-btn').forEach((btn) => {
        const active = btn.dataset.basis === basis;
        btn.classList.toggle('active', active);
        btn.setAttribute('aria-pressed', String(active));
      });
    }
    const machineActive = Dashboard._widthMachine !== 'all';
    const sel = document.getElementById('width-machine-select');
    if (sel && sel.value !== String(Dashboard._widthMachine)) sel.value = String(Dashboard._widthMachine);
    const labelEl = document.getElementById('width-basis-label');
    if (labelEl) {
      labelEl.textContent = machineActive
        ? `${basis === 'rollCount' ? 'تعداد' : 'خام موجود'} — دستگاه ${U.faNum(Dashboard._widthMachine)}`
        : (basis === 'rollCount' ? 'تعداد' : 'خام موجود');
    }
  };

  /** رندر نمودار افقی عرض‌ها از گزارش تولید ستاپ‌ها
   *  (نسخهٔ ۳٫۵ — تغییر ۲: فیلتر دستگاه — فقط رکوردهای ستاپ‌های دستگاهِ انتخاب‌شده) */
  Dashboard.renderWidthInventoryChart = function (state) {
    let report = state.setupReport;
    const el = document.getElementById('width-inventory-chart');
    if (!el) return;

    const basis = Dashboard._widthBasis === 'rollCount' ? 'rollCount' : 'rawExisting';
    const isRaw = basis === 'rawExisting';
    const basisLabel = isRaw ? 'خام موجود' : 'تعداد';
    const machineFilter = Dashboard._widthMachine;
    const machineActive = machineFilter !== 'all' && (machineFilter === 1 || machineFilter === 2 || machineFilter === 3);
    if (machineActive && Array.isArray(report)) {
      report = report.filter((r) => Number(r.machineNumber) === Number(machineFilter));
    }

    // توضیح پنل بر اساس مبنای فعال + فیلتر دستگاه
    const machinePhrase = machineActive ? ` دستگاه ${U.faNum(machineFilter)}` : '';
    const descEl = document.getElementById('width-inventory-desc');
    if (descEl) {
      descEl.innerHTML = isRaw
        ? `هر میله یک عرض است — مجموع ستون «خام موجود» رکوردهای${machinePhrase ? ` ستاپ‌های${machinePhrase}` : ''} همان عرض از جدول «گزارش تولید ستاپ‌ها»؛ فقط عرض‌هایی نمایش داده می‌شوند که رول خام موجود (مقدار مثبت) دارند — مرتب‌شده از عرض بزرگ به کوچک؛ عدد روی هر میله = تعداد رول خام موجود همان عرض.`
        : `هر میله یک عرض است — مجموع ستون «تعداد» رکوردهای${machinePhrase ? ` ستاپ‌های${machinePhrase}` : ''} همان عرض از جدول «گزارش تولید ستاپ‌ها»؛ همهٔ عرض‌های دارای تعداد مثبت — مرتب‌شده از عرض بزرگ به کوچک؛ عدد روی هر میله = تعداد رول همان عرض.`;
    }

    if (!report.length) {
      Dashboard.disposeChart('width-inventory-chart');
      el.style.height = '';   // بازگشت به ارتفاع پیش‌فرض (نسخهٔ ۳٫۴)
      el.innerHTML = `
        <div class="empty-state" style="min-height:180px">
          ${UI.icons.alert}
          <p>${machineActive
            ? `هنوز ستاپی برای دستگاه ${U.faNum(machineFilter)} ثبت نشده — عرض‌های رول این دستگاه پس از ثبت ستاپ‌ها نمایش داده می‌شوند.`
            : 'هنوز ستاپی ثبت نشده — عرض‌های رول پس از ثبت ستاپ‌ها در این نمودار نمایش داده می‌شوند.'}</p>
        </div>`;
      return;
    }

    // گروه‌بندی رکوردها بر اساس عرض — مجموع ستون مبنا
    const byWidth = new Map();   // width → { width, total, records }
    for (const r of report) {
      const w = Number(r.width);
      if (!Number.isFinite(w) || w <= 0) continue;
      if (!byWidth.has(w)) byWidth.set(w, { width: w, total: 0, records: 0 });
      const g = byWidth.get(w);
      g.total += Number(r[basis]) || 0;
      g.records++;
    }

    // فقط عرض‌های دارای مقدار مثبت در مبنای فعال + مرتب‌سازی عرض نزولی (بزرگ → کوچک)
    const groups = [...byWidth.values()]
      .filter((g) => g.total > 0)
      .sort((a, b) => b.width - a.width);

    if (!groups.length) {
      Dashboard.disposeChart('width-inventory-chart');
      el.style.height = '';   // بازگشت به ارتفاع پیش‌فرض (نسخهٔ ۳٫۴)
      el.innerHTML = `
        <div class="empty-state" style="min-height:180px">
          ${UI.icons.alert}
          <p>${isRaw
            ? 'هیچ عرضی با رول خام موجود (مقدار مثبت ستون «خام موجود») وجود ندارد.'
            : 'هیچ عرضی با تعداد مثبت وجود ندارد.'}</p>
        </div>`;
      return;
    }

    if (!Dashboard.hasECharts()) {
      // Fallback: فهرست متنی — عرض + تعداد
      el.innerHTML = `
        <div class="mt-rows" style="padding:12px; max-height:320px; overflow:auto">
          ${groups.map((g) => `<div class="mt-row">
              <div class="mt-label"><b>عرض ${U.faWidth(g.width)}</b> · ${U.faNum(g.records)} رکورد</div>
              <b>${U.faNum(g.total)} رول</b>
            </div>`).join('')}
        </div>`;
      return;
    }

    const P = Dashboard.chartPalette();
    const barColor = isRaw ? P.raw : P.setup;   // خام موجود = زمردی · تعداد = فیروزه‌ای

    /* ترتیب نمایش: بزرگ‌ترین عرض بالا — ECharts اندیس ۰ را پایین می‌چیند →
       آرایهٔ نمایشی معکوس (صعودی) ساخته می‌شود تا بزرگ‌ترین عرض در بالاترین میله بنشیند. */
    const view = [...groups].reverse();
    const cats = view.map((g) => U.faWidth(g.width));
    const values = view.map((g) => g.total);

    /* --- ارتفاع پویا (نسخهٔ ۳٫۴ — تغییر ۷): هر میله فضای کافی برای دیتالیبل
           می‌گیرد تا با زیاد شدن تعداد رول‌ها و کوتاه شدن میله‌ها، لیبل تعداد
           هرگز حذف یا همپوشان نشود — ارتفاع جعبه با تعداد میله‌ها رشد می‌کند. --- */
    const perBar = view.length > 40 ? 22 : 26;
    const boxH = Math.max(320, Math.round(view.length * perBar + 64));
    el.style.height = `${boxH}px`;

    /* فونت تطبیقی لیبل — دیتالیبل همیشه روشن است (نسخهٔ ۳٫۴ — تغییر ۷) */
    const labelSize = view.length <= 20 ? 11 : view.length <= 34 ? 10 : 9.5;

    const option = {
      animationDuration: 550,
      textStyle: { fontFamily: P.fontFamily },
      // راست‌به‌چپ (مثل نمودار دستگاه‌ها): عرض‌ها در سمت راست، میله‌ها از راست به چپ
      grid: { left: 16, right: 8, top: 18, bottom: 8, containLabel: true },
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow', shadowStyle: { color: P.splitLine } },
        backgroundColor: P.tooltipBg,
        borderColor: P.tooltipBorder,
        borderWidth: 1,
        padding: [8, 12],
        textStyle: { color: P.text, fontFamily: P.fontFamily, fontSize: 12 },
        formatter: (params) => {
          const p = params[0];
          if (!p) return '';
          const g = view[p.dataIndex];
          return `<b>عرض ${U.faWidth(g.width)}</b><br>` +
            `${basisLabel}: <b>${U.faNum(g.total)} رول</b><br>` +
            `${U.faNum(g.records)} رکورد ستاپ با همین عرض`;
        },
      },
      xAxis: {
        type: 'value',
        inverse: true,                     // صفر در راست → رشد میله به چپ
        max: (v) => Math.max(v.max * 1.12, 4),
        axisLabel: {
          color: P.muted,
          fontFamily: P.fontFamily,
          fontSize: 10.5,
          formatter: (v) => U.faNumPlain(v),
        },
        splitLine: { lineStyle: { color: P.splitLine, width: 1 } },
        axisLine: { show: false },
        axisTick: { show: false },
        name: `تعداد رول (${basisLabel})`,
        nameLocation: 'middle',
        nameGap: 26,
        nameTextStyle: { color: P.faint, fontFamily: P.fontFamily, fontSize: 10.5 },
      },
      yAxis: {
        type: 'category',
        position: 'right',                  // اندازهٔ عرض‌ها در سمت راست
        data: cats,
        axisLabel: {
          color: P.text,
          fontFamily: P.fontFamily,
          fontSize: 11.5,
          fontWeight: 700,
        },
        axisLine: { lineStyle: { color: P.axisLine } },
        axisTick: { show: false },
        name: 'عرض (mm)',
        nameLocation: 'middle',
        nameGap: 44,
        nameTextStyle: { color: P.faint, fontFamily: P.fontFamily, fontSize: 10.5 },
      },
      series: [
        {
          name: basisLabel,
          type: 'bar',
          data: values,
          barMaxWidth: 24,
          itemStyle: { color: barColor, borderRadius: [4, 0, 0, 4] },
          emphasis: { itemStyle: { color: barColor, opacity: 0.82 } },
          label: {
            show: true,                        // دیتالیبل همیشه روشن (نسخهٔ ۳٫۴ — تغییر ۷)
            position: 'left',          // نوک میله (سمت چپ — رشد راست‌به‌چپ)
            color: P.dark ? '#e8ebef' : '#15181c',
            fontFamily: P.fontFamily,
            fontSize: labelSize,
            fontWeight: 700,
            formatter: (p) => (p.value ? U.faNum(p.value) : ''),
          },
        },
      ],
    };

    Dashboard.applyChart('width-inventory-chart', option);

    // همگام‌سازی ابعاد نمونهٔ موجود با ارتفاع پویای جدید (نسخهٔ ۳٫۴ — تغییر ۷)
    const widthInst = Dashboard._charts['width-inventory-chart'];
    if (widthInst) {
      try { widthInst.resize(); } catch (e) { /* noop */ }
    }
  };

  /* ---------- Fallback قدیمی: میله‌های CSS (نبود ECharts) ---------- */

  Dashboard.renderMachineTimeChartFallback = function (state) {
    const s = state.summary;
    const machines = RM.config.VALID_MACHINES;

    let maxVal = 0;
    for (const m of machines) {
      const t = s.machineTime[m];
      if (t) maxVal = Math.max(maxVal, t.setup, t.produced);
    }
    if (maxVal === 0) maxVal = 1;

    const rows = machines.map((m) => {
      const t = s.machineTime[m] || { setup: 0, produced: 0, records: 0 };
      const setupPct = Math.max(2, Math.round((t.setup / maxVal) * 100));
      const producedPct = Math.max(2, Math.round((t.produced / maxVal) * 100));
      const hasData = t.records > 0;

      return `
        <div class="mt-row" data-machine="${m}">
          <div class="mt-label">
            <b>دستگاه ${U.faNum(m)}</b>
            <span class="muted mt-records">${hasData ? `${U.faNum(t.records)} رکورد` : 'بدون رکورد مطابق'}</span>
          </div>
          <div class="mt-bars">
            <div class="mt-bar-line">
              <span class="mt-legend-setup" title="مانده زمان ستاپ = (تعداد − متالایز) × مدت زمان">ستاپ</span>
              <div class="mt-track">
                <div class="mt-bar mt-bar-setup" style="width:${hasData ? setupPct : 0}%"></div>
              </div>
              <span class="mt-val">${U.faDuration(t.setup)}</span>
            </div>
            <div class="mt-bar-line">
              <span class="mt-legend-produced" title="مانده زمان موجودی = خام موجود × مدت زمان">موجودی</span>
              <div class="mt-track">
                <div class="mt-bar mt-bar-produced" style="width:${hasData ? producedPct : 0}%"></div>
              </div>
              <span class="mt-val">${U.faDuration(t.produced)}</span>
            </div>
          </div>
        </div>`;
    }).join('');

    document.getElementById('machine-time-chart').innerHTML = `
      <div class="mt-legend-bar">
        <span class="mt-legend-item"><span class="mt-dot mt-dot-setup"></span> مانده زمان ستاپ ((تعداد − متالایز) × مدت زمان)</span>
        <span class="mt-legend-item"><span class="mt-dot mt-dot-produced"></span> مانده زمان موجودی (خام موجود × مدت زمان)</span>
      </div>
      <div class="mt-rows">${rows}</div>`;
  };

  /* ---------- مرکز هشدار + Drill-down رکوردهای عامل (§8 اصلاحات) ---------- */

  const SEVERITY_META = {
    error: { label: 'خطا', cls: 'alert-error' },
    warning: { label: 'هشدار', cls: 'alert-warning' },
  };

  Dashboard.renderAlerts = function (warnings) {
    const wrap = document.getElementById('alerts-list');
    const panel = document.getElementById('alerts-panel');

    if (!warnings.length) {
      panel.hidden = true;
      wrap.innerHTML = '';
      return;
    }

    panel.hidden = false;
    document.getElementById('alerts-count').textContent = U.faNum(warnings.length);

    wrap.innerHTML = warnings.map((w) => {
      const meta = SEVERITY_META[w.severity] || SEVERITY_META.warning;
      const hasDrill = !!w.drill;
      return `
        <div class="alert-item ${meta.cls}" role="alert" data-alert="${U.escapeHtml(w.type)}">
          <span class="alert-badge">${meta.label}</span>
          <div class="alert-body">
            <b>${U.escapeHtml(w.title)}</b>
            <p>${U.escapeHtml(w.detail)}</p>
          </div>
          ${hasDrill
            ? `<button type="button" class="btn btn-ghost btn-sm" data-alert-drill="${U.escapeHtml(w.type)}" title="نمایش رکوردهای عامل این هشدار">مشاهدهٔ رکوردها</button>`
            : (w.action
              ? `<button type="button" class="btn btn-ghost btn-sm" data-alert-action="${w.action}">مشاهده</button>`
              : '')}
        </div>`;
    }).join('');

    // دکمهٔ «مشاهدهٔ رکوردها» → Drill-down دقیق رکوردهای عامل همان هشدار
    wrap.querySelectorAll('[data-alert-drill]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const w = warnings.find((x) => x.type === btn.dataset.alertDrill);
        if (w) Dashboard.openDrill(w);
      });
    });

    // هشدارهای بدون Drill → رفتن به بخش مرتبط (رفتار قبلی حفظ شد)
    wrap.querySelectorAll('[data-alert-action]').forEach((btn) => {
      btn.addEventListener('click', () => UI.switchTab(btn.dataset.alertAction));
    });
  };

  /**
   * بازکردن Drill-down یک هشدار — دقیقاً رکوردهای عامل همان Rule.
   * موجودیت‌های Roll از مودال مشترک با ستون‌های Mapping استفاده می‌کنند؛
   * هشدارهای مربوط به ستاپ/قانون جدول اختصاصی خودشان را می‌گیرند.
   */
  Dashboard.openDrill = async function (warning) {
    const d = warning.drill;
    if (!d) return;

    try {
      /* --- هشدارهای مربوط به ستاپ‌ها --- */
      if (d.source === 'setups') {
        const state = Dashboard._state;
        const rows = (d.filter === 'capacity-conflict')
          ? state.setupReport.filter((r) => r.conflict > 0)
          : (d.filter === 'no-time-rule')
            ? state.setupReport.filter((r) => r.remainingSetupTime === null)
            : state.setupReport.filter((r) => r.thickness === null || r.standardLength === null);

        const timeCols = (d.filter === 'no-time-rule')
          ? '<th>مانده زمان</th>'
          : '<th>خام</th><th>متالایز</th><th>مغایرت</th>';

        UI.infoModal(warning.title, `
          <div class="drill-subtitle"><b>${U.faNum(rows.length)}</b> رکورد ستاپ</div>
          <div class="table-wrap table-scroll" style="max-height:420px">
            <table class="data-table">
              <thead><tr><th>ستاپ</th><th>دستگاه</th><th>عرض</th><th>ضخامت</th><th>متراژ استاندارد</th><th>تعداد</th>${timeCols}</tr></thead>
              <tbody>${rows.map((r) => `
                <tr>
                  <td>${U.faNum(r.setupNumber)}</td>
                  <td>${U.faNum(r.machineNumber)}</td>
                  <td>${U.faWidth(r.width)}</td>
                  <td>${r.thickness === null ? '<span class="muted">ناقص</span>' : U.faNum(r.thickness)}</td>
                  <td>${r.standardLength === null ? '<span class="muted">ناقص</span>' : U.faNum(r.standardLength)}</td>
                  <td class="count-cell">${U.faNum(r.rollCount)}</td>
                  ${d.filter === 'no-time-rule'
                    ? `<td><span class="muted">بدون قانون زمان</span></td>`
                    : `<td>${U.faNum(r.rawExisting)}</td>
                       <td>${U.faNum(r.metallized)}</td>
                       <td>${r.conflict > 0 ? `<span class="pill-bad status-pill">⚠ ${U.faNum(r.conflict)}</span>` : '—'}</td>`}
                </tr>`).join('')}
              </tbody>
            </table>
          </div>
        `);
        return;
      }

      /* --- هشدار هم‌پوشانی قوانین --- */
      if (d.source === 'rules') {
        UI.infoModal(warning.title, `
          <div class="drill-subtitle"><b>${U.faNum(d.pairs.length)}</b> جفت قانون هم‌پوشان</div>
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>ضخامت</th><th>بازهٔ قانون ۱</th><th>بازهٔ قانون ۲</th></tr></thead>
              <tbody>${d.pairs.map(([a, b]) => `
                <tr>
                  <td class="thickness-cell">${U.faNum(a.thickness)}</td>
                  <td>${U.faNum(a.minLength)} تا ${U.faNum(a.maxLength)} → ${U.faNum(a.standardLength)}</td>
                  <td>${U.faNum(b.minLength)} تا ${U.faNum(b.maxLength)} → ${U.faNum(b.standardLength)}</td>
                </tr>`).join('')}
              </tbody>
            </table>
          </div>
        `);
        return;
      }

      /* --- هشدارهای رکوردی (rolls / archived) → مودال مشترک --- */
      const sourceKey = d.source;
      const table = RM.config.IMPORT_TARGETS[sourceKey].table;
      let records = [];

      if (d.issue) {
        // نقص دادهٔ مستقیم: بدون عرض / بدون متراژ / بدون ضخامت / شماره رول / نوع فیلم
        // رزولور مشترک نقص‌ها («length» → actualLength در مدل داخلی)
        const all = await db[table].toArray();
        records = RM.normalize.recordsWithIssue(all, d.issue);
      } else if (d.filter === 'all') {
        // Mapping ناقص — همهٔ رکوردهای همان Dataset (فیلدهای مفقود «—» نمایش داده می‌شوند)
        records = await db[table].toArray();
      } else if (d.filter === 'no-rule') {
        // رول‌های خام بدون قانون متراژ — از گروه‌های بدون قانون (کلید‌محور)
        const state = Dashboard._state;
        const groups = state.rawRollGroups.filter((g) => !g.hasRule);
        const ids = groups.flatMap((g) => g.rollIds);
        records = (await db.rolls.bulkGet(ids)).filter(Boolean);
      } else if (d.filter === 'group') {
        // گروه‌های خاص (بدون ستاپ / مازاد خام)
        const state = Dashboard._state;
        const keySet = new Set(d.groupKeys || []);
        const groups = state.rawRollGroups.filter((g) => keySet.has(g.key));
        const ids = groups.flatMap((g) => g.rollIds);
        records = (await db.rolls.bulkGet(ids)).filter(Boolean);
      } else if (d.filter === 'metallized-uncut-overdue') {
        // رول‌های متالایزشدهٔ برش‌نشده از مهلت گذشته (نسخهٔ ۳٫۵ — تغییر ۹):
        // شناسه‌ها از موتور محاسبه — M دارد ولی بازوی برش (R/L) ندارد و از
        // «تاریخ تولید» بیش از مهلت مجاز (تنظیمات) گذشته‌اند.
        const ids = Array.isArray(d.ids) ? d.ids : [];
        const got = ids.length ? await db.rolls.bulkGet(ids) : [];
        records = await RM.edits.applyToRecords('rolls', got.filter(Boolean));
      } else if (d.filter === 'metallized-unallocated') {
        // مازاد متالایز — یونیک‌های دارای کلیدِ تخصیص‌نیافته
        // نسخهٔ ۲٫۹: کلید شامل هویت رول (خط تولید + سالن + رقم سال از شمارهٔ رول)
        // نسخهٔ ۳٫۱ — تغییر ۳: کلید متالایز شامل «متراژ استاندارد» هم هست و از
        // نقشهٔ آمادهٔ موتور محاسبه (keyByRollNumber) خوانده می‌شود — بازسازی
        // دستی کلید اینجا حذف شد تا همیشه هم‌قالب با موتور بماند.
        const state = Dashboard._state;
        const keySet = new Set(d.groupKeys || []);
        const keyMap = state.metallizedKeyByRollNumber || {};
        records = state.metallizedUniqueRecords.filter((r) =>
          keySet.has(keyMap[String(r.rollNumber ?? '')]));
      } else if (d.filter === 'metallized-width-mismatch') {
        // رول‌های متالایز با عرض تعریف‌نشده در ستاپ (نسخهٔ ۳٫۷ — تغییر ۳):
        // کلید ۵فاکتوری (متراژ استاندارد + ستاپ + خط + سالن + سال) با ستاپ
        // مطابق ولی کلید کامل ۶فاکتوری (با عرض) با هیچ رکوردی مطابق نیست —
        // شناسه‌ها از موتور محاسبه (رکوردهای یونیک آرشیو)؛ نمایش با ویرایش‌های
        // کاربر (مودال مشترک با ستون‌های Mapping آرشیو).
        const ids = Array.isArray(d.ids) ? d.ids : [];
        const got = ids.length ? await db.archivedRolls.bulkGet(ids) : [];
        records = await RM.edits.applyToRecords('archived', got.filter(Boolean));
      }

      await UI.recordsDrillModal(warning.title, records, { source: sourceKey });
    } catch (err) {
      console.error('[Drill-down]', err);
      UI.toast('نمایش رکوردهای این هشدار با خطا مواجه شد.', 'error');
    }
  };

  /* ---------- اطلاعات آخرین Import (§12 — عنوان کاربرپسنده + نام فایل برای Audit) ---------- */

  Dashboard.renderImportBadges = async function () {
    for (const targetKey of ['rolls', 'archived']) {
      const el = document.getElementById(`kpi-file-${targetKey}`);
      if (!el) continue;

      const entries = await db.importMetadata
        .where('target').equals(targetKey)
        .reverse()
        .sortBy('importedAt');
      const info = entries[0];

      el.innerHTML = info
        ? `${U.escapeHtml(RM.config.DATASET_LABELS[targetKey])} — <code>${U.escapeHtml(U.truncate(info.fileName, 28))}</code> · ${U.faNum(info.totalRecords)} رکورد · ${U.faDate(info.importedAt)}`
        : '<span class="muted">فایلی بارگذاری نشده</span>';
    }
  };

  RM.views = RM.views || {};
  RM.views.dashboard = Dashboard;
})();
